# Actual reading coverage

| object | actual_extent | not_read_or_repeated | verification |
|---|---|---|---|
| 1A packet | checkpoint; scope/authority/conflicts; six RQ rows and downstream map; availability CSV; coverage note; snapshot | full opening inventory not re-audited; prior source files not all reread; prior external reading claims not inherited | all archive payload hashes independently checked |
| final 1B packet | checkpoint; all28 decision rows; adaptation memo; reading coverage; nine open questions; all6 deferred packages | three primary anchors not reopened; their actual source fidelity not independently reverified this turn | all archive payload hashes independently checked |
| GitHub current authority | AGENTS; AGENT_RUNBOOK; SEED_SOURCES; SEARCH_STRATEGY; RESEARCH_PROTOCOL fully read at pin; relevant issue delta/branches/openPRs | full issue body/comments and acceptance CI reused via preceding packet; no new CI/whole-tree audit | connector pinned content/collections |
| Institutional/author bibliographies | 2023 Nees–Liebman entries, relevant site/preprint links | unrelated personal/profile/publication content not audited or exported | author/institution identity agreement |
| Nees–Liebman comparator primary text | none; title/bibliographic metadata only | abstract, introduction, methods, results, tables, figures, discussion, supplements, underlying studies | not_read; no source SHA256 or screenshots |

The full-text acquisition budget is exhausted for this chunk. Zero comparator substantive sections, zero PDF page images, zero estimates and zero underlying studies were reviewed.
