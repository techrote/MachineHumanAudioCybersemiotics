# MHAC-R002 — chunk 1B portable packet

**Completed bounded methodology-anchor reading and provisional applicability analysis. Full R002 remains incomplete.** No accepted protocol, novelty synthesis, pilot search, production screening or remote publication is included.

## Start here

[CHECKPOINT](CHECKPOINT.md) contains the pin, entry decision, exact scope and continuation facts. [Entry reconciliation](findings/ENTRY_RECONCILIATION.md) reports only the relevant delta from the restored 1A packet.

## Methodological outputs

| Artifact | What it contains |
|---|---|
| [PRISMA 2020 record](readings/PRISMA_2020.md) | Statement/co-publication identity, complete checklist reading, selected expanded guidance, exact access/coverage limits. |
| [PRISMA-S record](readings/PRISMA_S.md) | All sixteen reporting items and explanations, image checks and limits. |
| [Original CIS record](readings/CIS_2006.md) | Methodological passages, appraisal/process tables and healthcare-transfer limitations. |
| [Source-to-decision matrix](matrices/SOURCE_TO_DECISION.md) / [CSV](matrices/SOURCE_TO_DECISION.csv) | 28 source-located provisional decisions; source claim, applicability, action, open question and verification status kept distinct. |
| [Two-track adaptation memo](findings/TWO_TRACK_ADAPTATION.md) | Empirical/theoretical selection boundaries and five classes of amendment/rescreening impact. |
| [Decisive open questions](findings/OPEN_QUESTIONS.md) | Nine unresolved decisions before novelty/pilot/analysis acceptance. |
| [Deferred guidance queue](matrices/DEFERRED_GUIDANCE.md) / [CSV](matrices/DEFERRED_GUIDANCE.csv) | Six prioritized packages; all additional source contents remain unread. |

## Provenance and coverage

[Authority manifest](SOURCE_AUTHORITY_MANIFEST.csv), [reading coverage](provenance/READING_COVERAGE.md), [source identities](provenance/SOURCE_IDENTITIES.json), [screenshot ledger](provenance/SCREENSHOT_LEDGER.csv), [web access ledger](provenance/WEB_ACCESS_LEDGER.json), [assistance limits](provenance/ASSISTANCE_AND_LIMITS.json), [commands/results](logs/COMMANDS_AND_RESULTS.md) and [content review](logs/CONTENT_REVIEW.md) document actual work. Source PDFs/full texts are not included; byte hashes of web-rendered originals are unavailable, not fabricated.

## Verified 1A lineage

The original [1A ZIP](inputs/MHAC_R002_chunk1A_packet_2026-10-04.zip) and its [original receipt](inputs/MHAC_R002_chunk1A_archive_verification.json) are included unchanged. [This turn's restore receipt](provenance/RESTORE_1A_RECEIPT.json) records verified restoration. The original ZIP contains its own checkpoint, six-RQ/14-family maps, illustrative examples, evidence and six-file partial source export. It is not a complete Git checkout. Reuse that actual packet rather than treating this summary as its replacement.

## Offline verification

From the extracted top directory, run:

```sh
python scripts/verify_packet.py .
```

The verifier checks SHA256SUMS, payload inventory, UTF-8/JSON/CSV/Python syntax, local links, bounded matrix/coverage consistency and the nested original 1A ZIP. It does **not** run repository tests, validate scientific truth or establish PRISMA compliance. The checksum manifest excludes itself. The external archive-verification receipt separately records the archive hash, member/readability checks and actual verifier result.

Authoring scripts under `scripts/` generate local advisory documents, not research schemas. They are provided for auditability. Do not import the packet wholesale into a future live registry, overwrite another worker's protocol, or mistake exploratory notes for accepted methodology. Publication and any next chunk need separate authorization and fresh reconciliation.
