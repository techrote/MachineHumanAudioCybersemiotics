# Decisive questions before novelty and pilot decisions

[Checkpoint](../CHECKPOINT.md) · [Adaptation memo](TWO_TRACK_ADAPTATION.md) · [Deferred methods](../matrices/DEFERRED_GUIDANCE.md)

**No novelty or pilot work has been executed.** These are open decisions with dependencies, not a successor prompt. The protocol-construction documents and 1A RQ/record maps remain the scope basis; nothing here supplies missing evidence.

| Decision | Why it matters | Evidence/action still needed | What is already usable |
|---|---|---|---|
| Exact empirical review product and nesting of comparisons | “Evidence map” does not by itself define selection, appraisal or synthesis conduct. | Choose and justify the product and methods after D01/D02; preserve a non-pooling option. | Six-RQ routing and P01/P04/P07. |
| Nearest-review overlap and candidate contribution | No novelty follows from combining a project name with known interface methods. | Directly read and assess Nees–Liebman2023's scope, methods, outcomes and coverage in a separately authorized phase; examine de Souza as a different kind of comparator. | 1A's named leads only; no methods/results/overlap evidence read here. |
| Operational outcome boundaries | Recognition, comprehension, correct action, latency and preference may answer different questions. | Pilot a coding distinction with heterogeneous and contrary examples; decide measures/timepoints and missing-result handling before production extraction. | P06/P09 and 1A illustrative mappings, not study evidence. |
| Actual searchable channels and lawful exports | A publisher page or web preview does not establish database access, complete results or redistribution rights. | Test each actual platform later, preserving exact syntax, limitations, pagination and failed attempts; never hide inaccessible coverage. | S02–S07 reporting obligations and disclosure fields. |
| Empirical versus theoretical selection status | One source's argumentative usefulness must not make its outcome estimates eligible or credible by fiat. | Explicit lane/selection purposes and cross-lane reference rules; preserve editions and study/report/sample families. | P03/P08, C02/C03. No schema has been installed. |
| Prior exposure and decision verification | Seed familiarity and project preference may shape queries and interpretations. | Disclose actual prior corpus/discussion exposure, agent roles and available human checks; choose D03/D04 safeguards before relying on automated decisions. | Agent-only 1B disclosure and the source-located role requirements. |
| Concept-revision impact and stopping | Iteration could change eligibility, extraction or a synthesis group after results are known. | Adopt an amendment/impact/rescreening policy and theory negative-case/stopping record; identify who can accept the change and rework. | The adaptation memo's five illustrative change classes; none enacted. |
| Estimands, dependence, bias and non-pooling | Reporting an analysis does not make it statistically defensible. | Resolve D05/D06 before extraction-driven result selection; define treatment/construct comparability, units and independent observation levels. | P07 and separate identity/reporting requirements; no estimator chosen. |
| Infrastructure and future integration | Missing R001 acceptance prevents a claimed accepted R002 freeze. | Reconcile any later R001/R002 candidate and its actual tests/acceptance; map proposals to its authoritative records without replacing an owner. | Restored 1A packet plus the narrowly refreshed 1B remote snapshot. |

## Continuation decision

The three-anchor review is no longer missing; do not repeat it from seed snippets. Its results are usable as **provisional methodology inputs**. A later novelty/overlap stage still needs actual comparator texts; a pilot stage still needs operational choices and truthful verification capacity. D01/D02/D03 are particularly relevant before calling a pilot method settled, while D05/D06 must precede result-driven extraction/analysis selection. These ordering notes do not authorize execution of a new stage or waive R001 acceptance.

No source-access emergency or new human request was identified for this bounded chunk. Future access or specialist-review gates should be raised only with a specific need and evidence; no contacts, purchases, registrations or participant actions are authorized by these notes.
