# Two-track adaptation memo

[Decision matrix](../matrices/SOURCE_TO_DECISION.md) · [Open questions](OPEN_QUESTIONS.md) · [Deferred guidance](../matrices/DEFERRED_GUIDANCE.md)

**Status: provisional methodological interpretation for MHAC-R002 preparation.** Nothing here is an accepted protocol amendment, freeze, novelty claim or implementation. Matrix IDs identify checked source passages; the repository arrangements proposed below are this assistant's adaptation, not claims that those arrangements were validated by the anchors.

## Why this transfer is plausible, and where it stops

MHAC already distinguishes the reconstruction of arguments about meaning and communication from comparisons of auditory-interface outcomes. The proposed match to CIS is the problem structure: contested constructs, heterogeneous kinds of text and an aim to examine how a field frames its questions. This is an **analogy about methodological needs**, not evidence that a healthcare-origin method will produce correct philosophical or HCI conclusions. See C01–C03, C05–C08 and the [CIS reading record](../readings/CIS_2006.md).

Three differences prevent automatic transfer. Books and philosophical arguments require edition-sensitive reconstruction and argumentative appraisal; they are not all empirical healthcare reports. The empirical audio track must retain design-, measurement- and sample-specific appraisal instead of letting theoretical interest determine effect credibility. Finally, this preparation used one assistant, not a multidisciplinary human review team. Disagreement generation by a model may aid checking but cannot claim the original team's disciplinary deliberation or independent human judgment.

Consequently, describe the eventual approach as a **documented CIS-informed adaptation**, unless later work justifies a stronger label. Do not import the healthcare paper's concepts, original sample numbers, informal practices or appraisal prompts as an already validated MHAC method.

## Two selection logics, shared provenance

Keep the six RQs from 1A. RQ1/RQ2 use primary-text reconstruction, argument comparisons and purposive/theoretical sampling. RQ3 uses systematic empirical selection and an evidence-map/conditional-synthesis route. RQ4/RQ5 integrate distinct kinds of evidence without merging their standards; RQ6 remains downstream design/evaluation derivation. This is routing, not execution or corpus selection.

For the empirical lane, the **future accepted protocol** must define eligibility, outcome families, result-selection rules, search coverage, estimands, appraisal and analysis decisions after transparent pilots and before production selection. Those choices are not supplied by a reporting checklist. For the theoretical lane, keep sensitizing concepts revisable and record argument-driven additions, contrary cases, competing readings and the rationale for stopping. A list of retrieved theoretical texts is not evidence of exhaustive coverage or conceptual saturation.

Use common source/access/reading provenance, but separate an empirical screening decision from a theoretical sampling decision. A source not sampled for reconstruction is not thereby empirically ineligible. A report can be conceptually informative yet weak evidence of an intervention effect. Do not let the interpretive lane silently rescue a failed empirical eligibility decision, nor let a statistical-study hierarchy decide whether a philosophical argument deserves examination. Routing is to the existing planned R001 families, not a competing schema. See P03–P08 and C02–C04.

## A controlled bridge for conceptual changes

The following are **proposed impact rules**, not amendments made in this chunk. PRISMA's amendment disclosure and CIS's iterative reasoning motivate making the interface explicit; the detailed rescreening obligations come from project integrity and this adaptation, not a verbatim checklist rule. See P02/P06, S07, C01/C05.

| Illustrative change class | Proposed record/action | When empirical rescreening is needed |
|---|---|---|
| A label or interpretation changes, with demonstrably unchanged search/eligibility/outcome boundaries. | Version the concept memo; document the no-impact rationale and affected interpretations. | Not automatic. A recorded impact check must substantiate that prior decisions remain unchanged. |
| A construct is operationally narrowed or expanded so different studies become eligible. | Amend the rule and exposed evidence; backfill relevant search coverage; identify the affected included, excluded and pending decisions. | Reapply the revised rule consistently to all affected decisions, not only new or favourable hits. If the affected set cannot be bounded reliably, recheck the whole relevant empirical subset. |
| A synonym or conceptual lead reveals a search omission while eligibility stays fixed. | Amend the search strategy, preserve prior runs, execute a separately authorized supplemental/backfill search later and screen new hits under the unchanged rule. | New hits require screening. Previously screened decisions need revisiting only where the change exposes an error or alters rule interpretation; assess this explicitly. |
| “Comprehension” is split into message interpretation and correct action, changing extraction or outcome classification. | Amend the outcome/codebook and result-selection rule; preserve original coding; re-extract/recode the affected reports consistently. | Required if eligibility depended on the former category. Otherwise extraction/synthesis rework may suffice; do not call every recoding a screening change. |
| A synthesis group, estimand or dependence assumption changes after exposure to results. | Record timing, rationale, exposure and affected analyses; preserve planned versus revised outputs and justify sensitivity analysis later. | Only if selection criteria change. Reanalysis and outcome-selection checks can be necessary even without rescreening. |

An amendment proposal needs the old/new rule, actor, actual date and stage, evidence already seen, affected record IDs, necessary rework and completion signal. Keep the original 2026-10-04 literature cut-off unless separately and explicitly amended; changing a search term is not permission to move a date boundary retrospectively. No such search, recoding, reanalysis or amendment was performed here.

## Provenance is not identical interpretation

The traceability goal is that another reader can inspect which passages, premises, counterarguments and decisions support a conclusion. It is not a promise that a different reader will infer the same theory. Preserve the boundary between author assertion, faithful reconstruction, contested interpretation, synthesis proposition and design hypothesis. C04 and C07 identify why the project's minimum locator/extraction audit is a deliberately stronger recording choice, not a reproduction of every original CIS practice.

Likewise, repeatable file exports and tests address structural reproducibility. They do not independently establish source fidelity, interpretive adequacy or human communication performance. The programme's stage graph can organize work while controlled theoretical feedback reopens relevant earlier work. A newly needed source is a reason for documented rework, not permission to bypass dependencies or retroactively pretend the earlier corpus was exhaustive.

## Outcomes and “certainty” must not collapse

Retain comprehension and correct action as different empirical outcome families; neither a sound being recognized nor a response being acknowledged proves both. Separate response latency, error type, learning, retention and workload, with stimulus, training and domain context. The project's preference for non-human emotional performance belongs in the constraint/exposure record, not the empirical inclusion rule or a claimed benefit. These distinctions are inherited project requirements and proposed operational safeguards, not findings of these methodological papers.

Distinguish **message diagnostic confidence**, **certainty in a synthesized body of evidence**, and **urgency/time-to-action**. A change in one is not automatically a change in the others. Hazard severity and task consequence also need distinct fields. No acoustic encoding, measurement instrument or estimator for these dimensions is selected here. P06/P07/P09 expose reporting needs but leave substantive measurement and analysis decisions open.

## Readiness and unresolved authority

Reporting applicability, conduct adequacy, source fidelity and scientific acceptance must remain separate (P01, S01). PRISMA-P is now a concrete missing protocol-reporting lead; evidence-map conduct, non-pooling, statistical/appraisal and contemporary AI-review guidance remain deferred. The next stage must not infer those methods from checklist item names.

At the assessed pin R001 acceptance is still unavailable as established by 1A, with no relevant published change visible in the 1B reconciliation. These notes can inform future methodology decisions but cannot become an accepted freeze, establish novelty, select a production corpus or satisfy human-review gates. Preserve existing worker boundaries and re-read any newly published candidate before integration. No new ownership is claimed.
