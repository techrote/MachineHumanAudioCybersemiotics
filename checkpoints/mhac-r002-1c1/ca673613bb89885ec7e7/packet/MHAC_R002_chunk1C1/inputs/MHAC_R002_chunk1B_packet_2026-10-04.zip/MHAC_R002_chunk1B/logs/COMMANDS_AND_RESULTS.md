# Commands and results — chunk1B

## Local execution

All shell/container commands in this chunk used an explicit **10000ms timeout**. They ran only in the new task workspace or read specified inputs/skill instructions. No command was used to mutate GitHub, another repository or shared hardware. No shell download, package install, git clone, repository test suite or research validator was run.

| Batch | Command/operation actually performed | Result and coverage |
|---|---|---|
| Entry files/clock/skill | `date -u`, list supplied1A files; read `/home/oai/skills/pdfs/SKILL.md` | Actual inputs existed; source-reading/PDF instructions read. |
| Isolated restoration | Python `tempfile.mkdtemp`, `zipfile` safe-name/duplicate/CRC checks and extraction into new directory |45 members restored; no prior workspace assumed. |
| Input verification | Python `hashlib.sha256` against original archive receipt and all 44 manifest entries; compare separately uploaded checkpoint bytes | All passed; receipt saved. |
| Prior scope reading | Read restored checkpoint, scope note, RQ map and finite reading queue | Entry permits1B; did not repeat full repo inventory. |
| Initial artifacts | Create initial checkpoint, restore receipt, remote observation summary, preliminary CIS notes; copy original 1A ZIP/receipt | Durable material existed before final packaging. Preliminary notes were replaced by final bounded records. |
| Reading output | `python scripts/build_content.py` | Three reading records,28 decision rows, five source-object coverage entries and15 screenshot-page locators. |
| Adaptation output | `python scripts/build_adaptation.py` | Provisional adaptation memo, nine open decision questions and six deferred method packages. |
| Provenance output | `python scripts/build_provenance.py` | Source/authority manifest, source/access/screenshot logs, scope delta and assistance limits. |
| Packet-only QA | `python scripts/verify_packet.py <packet-root>` and `python scripts/package_packet.py` | Actual final outcomes recorded in the external archive-verification receipt. Checks cover local syntax, references, hash/inventory/readability and nested 1A integrity only. |

The packet construction scripts are supplied for inspection. They are not R001 implementation, schema validators or scientific tests. Rebuilding authored files changes payload hashes and requires regeneration of SHA256SUMS.

## Remote and primary-source tool operations

GitHub connector operations were GET-only: entry branch collection, openPR collection, all-state recent issue updates, pinned AGENTS/runbook files, and one final branch/openPR check. Exact queries and selected observed fields are in the provenance JSON files. Entry and final pins agree; no separate published candidate was found. No CI checks were polled or workflow jobs triggered.

Web operations were direct primary HTML/PDF retrieval, official supporting links, bounded opens/finds within those anchors, and specified page screenshots. The resource-batch ledger and coverage records document what was read; they are not raw tool-output/source-text archives. An initial PRISMA statement DOI click failed with Internal Error; the official co-publication resolved access. No additional deferred guidance, review comparator or corpus source was opened. There were no novelty or pilot queries.

Web/connector tools do not expose a per-call timeout argument; their own service limits applied. No repeated asynchronous polling or background work occurred.

## Tests not performed

Repository/regulatory/scientific acceptance tests: **zero** in 1B. The four bootstrap tests inside1A remain historical results, not rerun1B tests. No live records exist here to validate, and an empty register was not used as evidence of completion. Source reading was checked by the assistant only, not independent human review. No statistical estimates or participant outcomes were calculated.

## Observed packet QA outcome

**PASS.** The bounded verifier checked all 33 packet files against the exact inventory and 32 payload SHA-256 entries, excluding the manifest itself. All 32 non-ZIP files were UTF-8 readable; seven JSON files, five CSV files and six Python files parsed. Forty-nine local Markdown links resolved. All 28 decision rows, six deferred packages, five source objects and fifteen distinct screenshot-page entries met the stated packet-only consistency checks.

The nested original 1A archive again passed its original archive hash, 45-member inventory, 44 payload hashes and CRC checks. The outer archive passed member inventory, CRCs and reading/hash comparison of every member against the local packet. These results concern transport and internal consistency only. The final outer archive hash is in the separately linked receipt. No external source byte hash or scientific result was validated.
