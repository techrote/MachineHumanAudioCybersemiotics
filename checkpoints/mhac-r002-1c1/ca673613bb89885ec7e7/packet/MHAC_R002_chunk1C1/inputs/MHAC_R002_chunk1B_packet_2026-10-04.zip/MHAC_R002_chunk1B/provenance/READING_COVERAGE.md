# Reading and access coverage

[Three records](../README.md) · [Machine-readable coverage](READING_COVERAGE.csv)

Five textual objects belong to three anchors, not five independent methodological studies. Fifteen distinct PDF pages were visually inspected across those five PDFs. All source-specific conclusions are limited to the ranges recorded below. Bibliographic references encountered in these sources are leads, not new readings.

| id | extent | not_read | screenshot_pages_1based | reading_status |
|---|---|---|---|---|
| A-P2020 | Main narrative; Scope/How to use; Box1 and Figure1; selected bibliography leads | Full E&E; abstract checklist Table2 systematic audit; cited studies | 3;8 | selected_ranges_read |
| A-P2020-C | All 27 items and subitems across both pages, visually inspected | No unlisted source contents implied | 1;2 | full_checklist_read |
| A-P2020-E | Intro and selected items3–13a,13d,16,24–27; specified page images | Whole ten-page item detail audit; full separate BMJ E&E | 2;3;4;5;7;10 | selected_ranges_read |
| A-PRISMAS | Main narrative; Parts2/3 all 16 item requirements and explanations; Part5; Tables1/3 and Figure1 | Separate Table2 glossary visual audit; linked supplements/data and cited sources | 4;11;15 | selected_ranges_read |
| A-CIS2006 | Background; complete methodological subsections; methodological Discussion/Reflections/Conclusion; Tables1/2 | Complete healthcare findings; underlying studies; linked references | 4;10 | selected_ranges_read |

Full HTML availability is not whole-item reading. Web-rendered content and page images were used; no original external file bytes were acquired for hashing. There are no primary source PDFs or full-text copies in the delivery packet. These limitations do not prevent the bounded applicability analysis; they prevent claims of a byte-pinned source archive, complete supporting-literature reading or independent source-fidelity audit.
