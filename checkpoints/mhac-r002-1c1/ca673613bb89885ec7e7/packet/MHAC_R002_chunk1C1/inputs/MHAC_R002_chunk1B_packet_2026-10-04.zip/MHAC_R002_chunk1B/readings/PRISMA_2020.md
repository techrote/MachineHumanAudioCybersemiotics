# Reading record — PRISMA 2020 anchor

[Matrix: P01–P10](../matrices/SOURCE_TO_DECISION.md) · [Coverage ledger](../provenance/READING_COVERAGE.csv)

## Identity and version

Page MJ, McKenzie JE, Bossuyt PM, et al. *The PRISMA 2020 statement: an updated guideline for reporting systematic reviews*. **Systematic Reviews 10:89, published 29 March 2021**, DOI `10.1186/s13643-021-01626-4`. This is the official co-publication actually read, not a claim to have read the BMJ PDF. The official PRISMA statement page lists the co-publications. The checklist cites the BMJ version, `10.1136/bmj.n71`; these are the same statement family, not independent methodological evidence.

Primary [statement](https://link.springer.com/article/10.1186/s13643-021-01626-4) and [PDF](https://link.springer.com/content/pdf/10.1186/s13643-021-01626-4.pdf); official [statement route](https://www.prisma-statement.org/prisma-2020-statement); [two-page checklist](https://www.prisma-statement.org/s/PRISMA_2020_checklist-ab3g.pdf); [expanded checklist](https://www.prisma-statement.org/s/PRISMA_2020_expanded_checklist-w7ra.pdf). Accessed **2026-10-04** via web retrieval.

## Actual reading and image coverage

The statement's main narrative was read from Introduction through Conclusion, with attention to Scope and How to use; Box1 glossary was inspected as a page image. Figure1 was inspected as a page image. The bibliography was scanned only for identified deferred references, not read as a corpus. File length: **11 pages**. Visually inspected **p3 (index2), p8 (index7)**. Table1 was covered using the official checklist, not separately as an article screenshot. The article's abstract-reporting Table2 was not systematically inspected.

The official checklist's **two complete pages** were read visually, including all 27 items and subitems. The ten-page expanded checklist was selectively read: introductory framing and selected items3–13a, 13d and16, plus24–27; contiguous neighbouring content was sometimes exposed. Page images inspected: **pp2,3,4,5,7,10 (indices1,2,3,4,6,9)**. Do not infer that unlisted pages or the full Explanation and Elaboration paper were read.

Reading status: **selected_ranges_read for the anchor; complete two-page checklist read**. Source passages and the specified images were checked by the assistant; no independent human source-fidelity check occurred. Exact locators for each retained point are in P01–P10.

## Retained methodological points

P01–P10 distinguish reporting from conduct, protocol reporting from review reporting, and records/reports/studies. They route selection, outcome, synthesis, amendment and disclosure information into proposed future repository records. Those routes are **our adaptation**, not a source-endorsed database design. In particular, P02's Git/date/exposure and P06's outcome separation are not declared source compliance.

## Access and limits

The first official DOI click returned a tool Internal Error. An official co-publication was then accessible in full HTML/PDF; therefore no statement access gap remains. The separate full BMJ Explanation and Elaboration paper (`10.1136/bmj.n160`), PRISMA-P and other linked guidance were **not read**. The expanded checklist is abridged supporting material, not a substitute for claiming the full E&E was inspected.

No source PDF or HTML is redistributed in this packet. Version identity uses DOI, publisher and accessed URL. External raw-byte SHA-256 is **unavailable: the web tools did not supply a local original byte file**. No hash is invented. The screenshot locators are reproducible access leads, not byte-pinned archival copies. Article findings about reporting uptake were not independently evaluated and are not used as project efficacy evidence.
