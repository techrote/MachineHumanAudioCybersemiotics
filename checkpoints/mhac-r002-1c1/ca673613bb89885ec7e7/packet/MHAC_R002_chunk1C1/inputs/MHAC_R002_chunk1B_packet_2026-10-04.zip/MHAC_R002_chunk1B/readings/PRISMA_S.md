# Reading record — PRISMA-S anchor

[Matrix: S01–S10](../matrices/SOURCE_TO_DECISION.md) · [Coverage ledger](../provenance/READING_COVERAGE.csv)

## Identity and version

Rethlefsen ML, Kirtley S, Waffenschmidt S, et al., with the PRISMA-S Group. *PRISMA-S: an extension to the PRISMA Statement for Reporting Literature Searches in Systematic Reviews*. **Systematic Reviews 10:39, published 26 January 2021**, DOI `10.1186/s13643-020-01542-z`. Primary [HTML](https://link.springer.com/article/10.1186/s13643-020-01542-z) and [PDF](https://link.springer.com/content/pdf/10.1186/s13643-020-01542-z.pdf). Accessed **2026-10-04** via web retrieval. This is the published article and its incorporated Explanation and Elaboration, not an earlier draft.

## Actual reading and image coverage

Read the title/abstract and substantive main narrative, including Introduction/development, Part2 Checklist, **all sixteen item requirements and their explanations in Part3**, and Part5 Discussion and conclusions. Published exemplars were read as illustrations inside this guidance, not independently verified studies or MHAC search records. The linked development datasets, supplementary search files and cited articles were not opened. Table2's glossary was not separately visually audited.

File length: **19 pages**. Visually inspected **Table1, p4 (index3)**; **Table3, p11 (index10)**; and **Figure1, p15 (index14)**. Figure1 is explicitly a **PRISMA 2009 example**, not the current PRISMA 2020 flow specification. S09 therefore requires version reconciliation rather than copying that image unchanged.

Reading status: **selected_ranges_read** at whole-item level because supplementary/development material and the complete reference apparatus were not reviewed; all material search-reporting items were read. Verification was by the assistant only, with no independent human check. Detailed decision locators are S01–S10.

## Retained methodological points

The matrix separates required reporting of methods actually used from decisions about which methods are appropriate. It also identifies source-specific totals, deduplication and updates as future record needs. S10 deliberately marks an extra project requirement: detailed term/concept decision rationales are not all mandated by PRISMA-S.

## Access and limits

Full HTML and PDF were accessible; no source access blocker remains for this bounded reading. References to PRESS, ROSES, PRISMA-P and other guidance are **discovery/access leads only**. Their original contents were not read. Current AI-review standards and performance thresholds are not established by this 2021 document.

No external source text/PDF is packaged. Original byte hash: **unavailable through the web retrieval used**. The source's examples and reported development process are author-reported material, not this assistant's reproduced experiments. Recording zero contacts or no peer review is preferable to inventing these activities; the paper does not authorize outreach, purchase or recruitment.
