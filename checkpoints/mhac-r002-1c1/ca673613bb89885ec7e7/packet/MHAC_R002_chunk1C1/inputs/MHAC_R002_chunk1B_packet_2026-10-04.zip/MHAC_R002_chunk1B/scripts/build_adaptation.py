"""Write bounded methodological proposals; these files do not freeze or change a protocol."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]
def put(path,text):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def writecsv(path,rows):
 with (ROOT/path).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def table(rows):
 cols=list(rows[0]);esc=lambda x:str(x).replace('|','\\|').replace('\n','<br>')
 return '| '+' | '.join(cols)+' |\n|'+'|'.join(['---']*len(cols))+'|\n'+'\n'.join('| '+' | '.join(esc(r[c]) for c in cols)+' |' for r in rows)
put('findings/TWO_TRACK_ADAPTATION.md','''# Two-track adaptation memo

[Decision matrix](../matrices/SOURCE_TO_DECISION.md) · [Open questions](OPEN_QUESTIONS.md) · [Deferred guidance](../matrices/DEFERRED_GUIDANCE.md)

**Status: provisional methodological interpretation for MHAC-R002 preparation.** Nothing here is an accepted protocol amendment, freeze, novelty claim or implementation. Matrix IDs identify checked source passages; the repository arrangements proposed below are this assistant's adaptation, not claims that those arrangements were validated by the anchors.

## Why this transfer is plausible, and where it stops

MHAC already distinguishes the reconstruction of arguments about meaning and communication from comparisons of auditory-interface outcomes. The proposed match to CIS is the problem structure: contested constructs, heterogeneous kinds of text and an aim to examine how a field frames its questions. This is an **analogy about methodological needs**, not evidence that a healthcare-origin method will produce correct philosophical or HCI conclusions. See C01–C03, C05–C08 and the [CIS reading record](../readings/CIS_2006.md).

Three differences prevent automatic transfer. Books and philosophical arguments require edition-sensitive reconstruction and argumentative appraisal; they are not all empirical healthcare reports. The empirical audio track must retain design-, measurement- and sample-specific appraisal instead of letting theoretical interest determine effect credibility. Finally, this preparation used one assistant, not a multidisciplinary human review team. Disagreement generation by a model may aid checking but cannot claim the original team's disciplinary deliberation or independent human judgment.

Consequently, describe the eventual approach as a **documented CIS-informed adaptation**, unless later work justifies a stronger label. Do not import the healthcare paper's concepts, original sample numbers, informal practices or appraisal prompts as an already validated MHAC method.

## Two selection logics, shared provenance

Keep the six RQs from 1A. RQ1/RQ2 use primary-text reconstruction, argument comparisons and purposive/theoretical sampling. RQ3 uses systematic empirical selection and an evidence-map/conditional-synthesis route. RQ4/RQ5 integrate distinct kinds of evidence without merging their standards; RQ6 remains downstream design/evaluation derivation. This is routing, not execution or corpus selection.

For the empirical lane, the **future accepted protocol** must define eligibility, outcome families, result-selection rules, search coverage, estimands, appraisal and analysis decisions after transparent pilots and before production selection. Those choices are not supplied by a reporting checklist. For the theoretical lane, keep sensitizing concepts revisable and record argument-driven additions, contrary cases, competing readings and the rationale for stopping. A list of retrieved theoretical texts is not evidence of exhaustive coverage or conceptual saturation.

Use common source/access/reading provenance, but separate an empirical screening decision from a theoretical sampling decision. A source not sampled for reconstruction is not thereby empirically ineligible. A report can be conceptually informative yet weak evidence of an intervention effect. Do not let the interpretive lane silently rescue a failed empirical eligibility decision, nor let a statistical-study hierarchy decide whether a philosophical argument deserves examination. Routing is to the existing planned R001 families, not a competing schema. See P03–P08 and C02–C04.

## A controlled bridge for conceptual changes

The following are **proposed impact rules**, not amendments made in this chunk. PRISMA's amendment disclosure and CIS's iterative reasoning motivate making the interface explicit; the detailed rescreening obligations come from project integrity and this adaptation, not a verbatim checklist rule. See P02/P06, S07, C01/C05.

| Illustrative change class | Proposed record/action | When empirical rescreening is needed |
|---|---|---|
| A label or interpretation changes, with demonstrably unchanged search/eligibility/outcome boundaries. | Version the concept memo; document the no-impact rationale and affected interpretations. | Not automatic. A recorded impact check must substantiate that prior decisions remain unchanged. |
| A construct is operationally narrowed or expanded so different studies become eligible. | Amend the rule and exposed evidence; backfill relevant search coverage; identify the affected included, excluded and pending decisions. | Reapply the revised rule consistently to all affected decisions, not only new or favourable hits. If the affected set cannot be bounded reliably, recheck the whole relevant empirical subset. |
| A synonym or conceptual lead reveals a search omission while eligibility stays fixed. | Amend the search strategy, preserve prior runs, execute a separately authorized supplemental/backfill search later and screen new hits under the unchanged rule. | New hits require screening. Previously screened decisions need revisiting only where the change exposes an error or alters rule interpretation; assess this explicitly. |
| “Comprehension” is split into message interpretation and correct action, changing extraction or outcome classification. | Amend the outcome/codebook and result-selection rule; preserve original coding; re-extract/recode the affected reports consistently. | Required if eligibility depended on the former category. Otherwise extraction/synthesis rework may suffice; do not call every recoding a screening change. |
| A synthesis group, estimand or dependence assumption changes after exposure to results. | Record timing, rationale, exposure and affected analyses; preserve planned versus revised outputs and justify sensitivity analysis later. | Only if selection criteria change. Reanalysis and outcome-selection checks can be necessary even without rescreening. |

An amendment proposal needs the old/new rule, actor, actual date and stage, evidence already seen, affected record IDs, necessary rework and completion signal. Keep the original 2026-10-04 literature cut-off unless separately and explicitly amended; changing a search term is not permission to move a date boundary retrospectively. No such search, recoding, reanalysis or amendment was performed here.

## Provenance is not identical interpretation

The traceability goal is that another reader can inspect which passages, premises, counterarguments and decisions support a conclusion. It is not a promise that a different reader will infer the same theory. Preserve the boundary between author assertion, faithful reconstruction, contested interpretation, synthesis proposition and design hypothesis. C04 and C07 identify why the project's minimum locator/extraction audit is a deliberately stronger recording choice, not a reproduction of every original CIS practice.

Likewise, repeatable file exports and tests address structural reproducibility. They do not independently establish source fidelity, interpretive adequacy or human communication performance. The programme's stage graph can organize work while controlled theoretical feedback reopens relevant earlier work. A newly needed source is a reason for documented rework, not permission to bypass dependencies or retroactively pretend the earlier corpus was exhaustive.

## Outcomes and “certainty” must not collapse

Retain comprehension and correct action as different empirical outcome families; neither a sound being recognized nor a response being acknowledged proves both. Separate response latency, error type, learning, retention and workload, with stimulus, training and domain context. The project's preference for non-human emotional performance belongs in the constraint/exposure record, not the empirical inclusion rule or a claimed benefit. These distinctions are inherited project requirements and proposed operational safeguards, not findings of these methodological papers.

Distinguish **message diagnostic confidence**, **certainty in a synthesized body of evidence**, and **urgency/time-to-action**. A change in one is not automatically a change in the others. Hazard severity and task consequence also need distinct fields. No acoustic encoding, measurement instrument or estimator for these dimensions is selected here. P06/P07/P09 expose reporting needs but leave substantive measurement and analysis decisions open.

## Readiness and unresolved authority

Reporting applicability, conduct adequacy, source fidelity and scientific acceptance must remain separate (P01, S01). PRISMA-P is now a concrete missing protocol-reporting lead; evidence-map conduct, non-pooling, statistical/appraisal and contemporary AI-review guidance remain deferred. The next stage must not infer those methods from checklist item names.

At the assessed pin R001 acceptance is still unavailable as established by 1A, with no relevant published change visible in the 1B reconciliation. These notes can inform future methodology decisions but cannot become an accepted freeze, establish novelty, select a production corpus or satisfy human-review gates. Preserve existing worker boundaries and re-read any newly published candidate before integration. No new ownership is claimed.
''')
q=[]
def add(id,priority,need,lead,basis,when,question):
 q.append(dict(id=id,priority=priority,unresolved_guidance=need,reference_or_access_lead=lead,discovered_in=basis,needed_before=when,decision_to_resolve=question,reading_status='not_read',access_status='not_attempted_in_1B',metadata_status='reference-as-listed in inspected anchor; primary/current version not independently verified',action_this_chunk='recorded only; not searched or settled'))
add('D01','1 — protocol foundation','Protocol-specific reporting',
'Moher et al. PRISMA-P 2015 statement, Syst Rev 4:1, DOI 10.1186/2046-4053-4-1; Shamseer et al. E&E, BMJ 350:g7647, DOI 10.1136/bmj.g7647.',
'PRISMA2020 Scope and references47–48; PRISMA-S Part2',
'Claiming a complete protocol/reporting plan or freeze',
'Which protocol reporting items apply to each lane, without freezing all theoretical constructs?')
add('D02','2 — pilot design','Evidence-map identity, conduct and reporting',
'Tricco et al. PRISMA-ScR (2018), DOI 10.7326/M18-0850; Haddaway et al. ROSES (2018), Environ Evid 7(1):7, as named in PRISMA-S reference142. ROSES DOI not verified here. Additional fit-for-purpose evidence-map conduct authority remains to be identified.',
'PRISMA2020 Scope/reference53; PRISMA-S Part5/reference142',
'Eligibility calibration and production evidence-map design',
'Is RQ3 an evidence map with nested comparisons, a scoping review, or another specified synthesis, and what conduct rules fit?')
add('D03','2 — before assisted pilot decisions','AI-assisted review reporting and verification',
'Baseline leads are PRISMA2020 expanded items7–9/11. No additional contemporary AI-review standard has been identified or assessed in 1B; locate an applicable primary standard later, not an invented title.',
'PRISMA2020 expanded disclosure items; PRISMA-S Part5 limits; project integrity',
'Automated pilot eligibility/extraction or reliance on automated exclusions',
'Which tool/version, decision-role disclosures and false-negative/extraction checks are needed, and what human verification actually exists?')
add('D04','3 — search acceptance','Search conduct and real search-specific peer review',
'McGowan et al. PRESS Peer Review of Electronic Search Strategies: 2015 guideline statement. J Clin Epidemiol 2016;75:40–46. DOI not verified here; access lead is PRISMA-S reference1. Searching/selecting chapter in Cochrane Handbook is another listed conduct lead, not read.',
'PRISMA-S item14 and references1–2',
'Acceptance of production search strategy',
'What strategy testing and genuine expert review are feasible? How must limitations be reported when no such reviewer is available?')
add('D05','3 — analysis decision rules','Non-pooling methods and reporting',
'Campbell et al. SWiM (2020), BMJ 368:l6890, DOI 10.1136/bmj.l6890; McKenzie and Brennan, Synthesizing and presenting findings using other methods (2019), DOI 10.1002/9781119536604.ch12.',
'PRISMA2020 references25/27 and item13d',
'Prespecifying a non-pooled synthesis route before result-driven selection',
'Which structured methods apply to each comparison? What cannot be inferred when constructs, designs or usable estimates differ?')
add('D06','3 — quantitative and appraisal rules','Estimands, dependence, missingness, appraisal and body-of-evidence certainty',
'Cochrane Handbook version6.0 (2019) as cited by PRISMA2020 reference43; https://training.cochrane.org/handbook is an access lead, current version not checked. Design-specific bias/measurement and evidence-certainty guidance still require selection and direct reading.',
'PRISMA2020 items11–15 and references28–32/43; expanded13d',
'Quantitative extraction/result selection and accepted analysis rules',
'How will repeated measures, shared controls, overlapping samples, missing variances and multiple outcomes be handled; when is pooling unjustified?')
writecsv('matrices/DEFERRED_GUIDANCE.csv',q)
put('matrices/DEFERRED_GUIDANCE.md','''# Prioritized deferred methodology queue

[Open questions](../findings/OPEN_QUESTIONS.md) · [Reading records](../README.md)

**Six finite decision packages, not six completed readings and not an instruction to search all adjacent literatures.** Priorities express project dependency, not source quality. All original materials below remain **not read** and **not accessed in 1B**. Their presence in an inspected reference list verifies the lead as listed, not the source's claims, current version or suitability. Modern AI-review and fit-for-purpose evidence-map conduct authorities remain specifically unidentified. Do not label any item accepted guidance yet.

'''+table([{'ID / priority':r['id']+' — '+r['priority'],'Unresolved guidance':r['unresolved_guidance'],'Reference / access lead':r['reference_or_access_lead'],'Locator in inspected anchor':r['discovered_in'],'Needed before':r['needed_before'],'Decision':r['decision_to_resolve']} for r in q])+'''

Primary anchor routes for these reference locators: [PRISMA2020 statement](https://link.springer.com/article/10.1186/s13643-021-01626-4) and [PRISMA-S](https://link.springer.com/article/10.1186/s13643-020-01542-z). No DOI resolution, source-content verification or claim about the current edition is implied for deferred entries. The full PRISMA2020 E&E (`10.1136/bmj.n160`) is also unreviewed supporting material within its existing anchor, to consult only for a specific unresolved item rather than opening an unlimited citation chain.
''')
put('findings/OPEN_QUESTIONS.md','''# Decisive questions before novelty and pilot decisions

[Checkpoint](../CHECKPOINT.md) · [Adaptation memo](TWO_TRACK_ADAPTATION.md) · [Deferred methods](../matrices/DEFERRED_GUIDANCE.md)

**No novelty or pilot work has been executed.** These are open decisions with dependencies, not a successor prompt. The protocol-construction documents and 1A RQ/record maps remain the scope basis; nothing here supplies missing evidence.

| Decision | Why it matters | Evidence/action still needed | What is already usable |
|---|---|---|---|
| Exact empirical review product and nesting of comparisons | “Evidence map” does not by itself define selection, appraisal or synthesis conduct. | Choose and justify the product and methods after D01/D02; preserve a non-pooling option. | Six-RQ routing and P01/P04/P07. |
| Nearest-review overlap and candidate contribution | No novelty follows from combining a project name with known interface methods. | Directly read and assess Nees–Liebman2023's scope, methods, outcomes and coverage in a separately authorized phase; examine de Souza as a different kind of comparator. | 1A's named leads only; no methods/results/overlap evidence read here. |
| Operational outcome boundaries | Recognition, comprehension, correct action, latency and preference may answer different questions. | Pilot a coding distinction with heterogeneous and contrary examples; decide measures/timepoints and missing-result handling before production extraction. | P06/P09 and 1A illustrative mappings, not study evidence. |
| Actual searchable channels and lawful exports | A publisher page or web preview does not establish database access, complete results or redistribution rights. | Test each actual platform later, preserving exact syntax, limitations, pagination and failed attempts; never hide inaccessible coverage. | S02–S07 reporting obligations and disclosure fields. |
| Empirical versus theoretical selection status | One source's argumentative usefulness must not make its outcome estimates eligible or credible by fiat. | Explicit lane/selection purposes and cross-lane reference rules; preserve editions and study/report/sample families. | P03/P08, C02/C03. No schema has been installed. |
| Prior exposure and decision verification | Seed familiarity and project preference may shape queries and interpretations. | Disclose actual prior corpus/discussion exposure, agent roles and available human checks; choose D03/D04 safeguards before relying on automated decisions. | Agent-only 1B disclosure and the source-located role requirements. |
| Concept-revision impact and stopping | Iteration could change eligibility, extraction or a synthesis group after results are known. | Adopt an amendment/impact/rescreening policy and theory negative-case/stopping record; identify who can accept the change and rework. | The adaptation memo's five illustrative change classes; none enacted. |
| Estimands, dependence, bias and non-pooling | Reporting an analysis does not make it statistically defensible. | Resolve D05/D06 before extraction-driven result selection; define treatment/construct comparability, units and independent observation levels. | P07 and separate identity/reporting requirements; no estimator chosen. |
| Infrastructure and future integration | Missing R001 acceptance prevents a claimed accepted R002 freeze. | Reconcile any later R001/R002 candidate and its actual tests/acceptance; map proposals to its authoritative records without replacing an owner. | Restored 1A packet plus the narrowly refreshed 1B remote snapshot. |

## Continuation decision

The three-anchor review is no longer missing; do not repeat it from seed snippets. Its results are usable as **provisional methodology inputs**. A later novelty/overlap stage still needs actual comparator texts; a pilot stage still needs operational choices and truthful verification capacity. D01/D02/D03 are particularly relevant before calling a pilot method settled, while D05/D06 must precede result-driven extraction/analysis selection. These ordering notes do not authorize execution of a new stage or waive R001 acceptance.

No source-access emergency or new human request was identified for this bounded chunk. Future access or specialist-review gates should be raised only with a specific need and evidence; no contacts, purchases, registrations or participant actions are authorized by these notes.
''')
print('Wrote adaptation, nine decision questions, and six deferred guidance packages.')
