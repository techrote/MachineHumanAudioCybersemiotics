"""Build local, provisional 1B reading/adaptation notes; not a research schema or validator."""
from pathlib import Path
import csv, json, shutil
ROOT=Path(__file__).resolve().parents[1]
MAIN='796151a33ec7a1acc026b239fe5c883312ebf40b'
P='https://link.springer.com/article/10.1186/s13643-021-01626-4'
PC='https://www.prisma-statement.org/s/PRISMA_2020_checklist-ab3g.pdf'
PE='https://www.prisma-statement.org/s/PRISMA_2020_expanded_checklist-w7ra.pdf'
S='https://link.springer.com/article/10.1186/s13643-020-01542-z'
C='https://link.springer.com/article/10.1186/1471-2288-6-35'
def put(path,text):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def csvwrite(path,rows):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def table(rows,columns):
    def esc(x):return str(x).replace('|','\\|').replace('\n','<br>')
    return '| '+' | '.join(columns)+' |\n|'+'|'.join(['---']*len(columns))+'|\n'+'\n'.join('| '+' | '.join(esc(r[c]) for c in columns)+' |' for r in rows)
rows=[]
def add(id,anchor,locator,claim,kind,applies,action,question,families):
    rows.append(dict(id=id,anchor=anchor,exact_locator=locator,source_claim=claim,source_statement_type=kind,
      applicability=applies,proposed_repository_action=action,unresolved_question=question,
      relevant_record_families=families,verification_status='agent_checked: cited passage and/or specified page image; project action provisional; no independent human check',
      implementation_status='not_implemented',source_url={'P':P,'S':S,'C':C}[anchor]))
# Short source statements; detailed project actions are our proposals, not quotations or source mandates.
add('P01','P','Statement: Scope of the guideline, paragraphs 1–7; PDF p3',
'Reporting guidance is not conduct or quality assessment.','guideline scope',
'Empirical reporting planning; theory uses only justified applicable elements.',
'Keep reporting coverage, methodological adequacy, source fidelity and research acceptance as separate states. Do not use checklist completion or green CI as a quality certificate.',
'What review type and additional conduct guidance fit RQ3?', 'Assistance/review; claim; protocol')
add('P02','P','Statement: Scope, paragraph beginning “Furthermore”; checklist 24a–c; expanded p10',
'Protocol reporting uses PRISMA-P; disclose registration, protocol access and amendments.','reporting recommendation',
'R002 preparation and later review report; no registration implied.',
'Defer PRISMA-P reading. Preserve truthful unregistered/internal-version status; later amendments need date, reason, stage, exposure and affected records. Git identifiers are project provenance, not external preregistration.',
'Which protocol fields and amendment authority will be accepted after R001?', 'Amendment; assistance/review; human gate')
add('P03','P','Statement Box1, PDF p3; Figure1, PDF p8; checklist 16a; expanded p7',
'Records, reports and studies differ; report selection flow and unretrieved reports.','definitions and reporting recommendation',
'Empirical evidence flow; theory needs a separately labelled sampling account.',
'When R001 exists, reconcile raw hits, deduplicated records, retrieved/unretrieved reports and study identities. Do not manufacture zero-filled completed flow from absent registries; distinguish multi-report studies from duplicate retrievals.',
'How will publication, report, edition, study, experiment and sample relationships be represented?', 'Search run/hit; screening; source/publication; study identity')
add('P04','P','Checklist items5–7, p1; expanded items5–7, pp1–2',
'Report eligibility, synthesis groups, sources, dates and full search strategies.','reporting recommendation',
'Empirical rules after transparent pilots; theoretical search rationale remains iterative.',
'Keep the 1A six-RQ map and actual channel/access inventory as preparation. Later store exact executable searches, coverage and exclusions separately from the theoretical concept log.',
'Which populations, tasks, cue comparisons, languages and dates are defensible?', 'Search run; screening; amendment')
add('P05','P','Checklist 8–9, p1; expanded 8–9, p3',
'Disclose selection/extraction actors, independence and automation.','reporting recommendation',
'Both tracks, with task-specific verification limits.',
'Log who or what made each decision, tool/version when known, input and reviewed range, conflicts and checks actually performed. Report absent dual-human screening and distinguish model agreement from independent human review.',
'What real verification capacity and automation error checks are feasible?', 'Screening; extraction; assistance/review')
add('P06','P','Checklist 10a–b, p1; expanded 10a–b, pp3–4; expanded 5, p2',
'Define outcomes, result selection, assumptions and changes.','reporting recommendation',
'RQ3 plus empirical components of RQ4/RQ5.',
'Specify comprehension, correct action, latency, retention and workload separately. Distinguish unmeasured outcomes from measured-but-unreported results; missingness is not zero. Preserve initial versus revised outcome and result-selection rules.',
'Which measurements and timepoints answer each question without outcome-driven selection?', 'Empirical extraction; amendment; appraisal')
add('P07','P','Checklist 11–15, p1; expanded 13d, p5',
'Report appraisal, effect measures and justified synthesis methods, including dependence handling.','reporting recommendation',
'Conditional quantitative and non-pooled empirical work.',
'Defer estimator, risk-of-bias and evidence-certainty choices to appropriate guidance. Prespecify per-comparison pooling and non-pooling decisions later; do not treat a generic cue-family label as treatment equivalence.',
'Which estimands, shared-sample handling and missing-data assumptions are defensible?', 'Study identity; appraisal; empirical extraction; protocol')
add('P08','P','Checklist 16b, p2; expanded 16b, p7',
'Explain exclusions that could appear eligible.','reporting recommendation',
'Empirical selection transparency; theory needs reasons suited to purposive sampling.',
'Retain rule/version and reason with every adjudicated decision; distinguish exclusion from inaccessible, pending or not sampled. Do not retroactively relabel unavailable text as irrelevant.',
'What reason taxonomy and adjudication procedure avoids conflating access and eligibility?', 'Screening; source/publication')
add('P09','P','Checklist 19–23, p2; especially 23b–c',
'Report results and both evidence and review-process limitations.','reporting recommendation',
'Later empirical synthesis and integrated interpretation, not current results.',
'Keep body-of-evidence certainty distinct from an interface message’s diagnostic certainty and its urgency. Preserve limitations of single-agent preparation, access gaps and domain transfer in any downstream claims.',
'How will each limitation constrain claim scope rather than become boilerplate?', 'Claim; appraisal; assistance/review')
add('P10','P','Checklist 25–27, p2; expanded 25–27, p10',
'Disclose support, conflicts and materials availability.','reporting recommendation',
'Current provenance and eventual report/package.',
'Describe actual AI assistance and project preference; prepare permission-safe derived records and reproducibility code. No source redistribution or external publication follows automatically from checklist advice.',
'Which inputs can lawfully be shared, and what must remain access-only?', 'Assistance/review; source/publication; human gate')
add('S01','S','Part2: Checklist, paragraphs1–5; Part5: Discussion and conclusions',
'Apply relevant reporting items; these are not conduct instructions.','guideline scope',
'Both tracks’ search reporting, not proof of exhaustive theory retrieval.',
'Use an applicability ledger with yes/no/not-applicable reasons. Do not require every biomedical database or contact method merely because an item exists.',
'Which search methods actually serve each RQ?', 'Search run; protocol')
add('S02','S','Items1–3: requirement and explanation; Table1, PDF p4',
'Identify databases, platforms, combined searches and registries.','reporting recommendation',
'Empirical searches and named theoretical retrieval channels.',
'Record actual accessible database/interface pairs and individual databases in a multi-database run. A web search directed at a publisher site is not an executed subscription-index search.',
'Which channel/interface combinations are available without new accounts or payment?', 'Search run')
add('S03','S','Item4: Web search engines and specific web sites; Conference proceedings',
'Describe purposeful browsing, result limits and how searching occurred.','reporting recommendation',
'Grey literature, proceedings, author/publisher sites and supplementary retrieval.',
'Later record native versus general-web interface, exact query, pages/results covered, visible restrictions and any personalization controls actually used. A bounded preview is not a full export.',
'What coverage limit can be justified and how will access failures be represented?', 'Search run/hit; source/publication')
add('S04','S','Items5–7: citation searching, contacts and other methods',
'Describe citation-search bases, contacts and other retrieval methods.','reporting recommendation',
'Both tracks; contacts only when separately authorized.',
'Trace backward/forward citation retrieval to its seed report and platform. Keep serendipitous/prior-known leads visible. Mark contacts not used where none occurred; no outreach is authorized here.',
'Which seeds and directions are warranted without privileging favourable literature?', 'Search run/hit; assistance/review; human gate')
add('S05','S','Item8: requirement and explanation; Table3, PDF p11',
'Provide exact as-run strategies and durable supplementary search information.','reporting recommendation',
'Future pilot and production searching; source access metadata now.',
'Preserve query text, exported metadata when permitted, dates and versioned manifests. Public exports require rights checks; do not assume abstracts or source texts may be redistributed.',
'What export granularity and lawful retention are feasible for each platform?', 'Search run/hit; source/publication')
add('S06','S','Items9–11: limits/restrictions, search filters and prior work',
'Disclose limits, filter adaptations and reused search work.','reporting recommendation',
'Later empirical search design and review-overlap assessment.',
'Distinguish eligibility rules, database limits and methodological search filters. Attribute a reused strategy to its origin and record modifications. Do not treat a prior review as independent primary outcome data.',
'Which limits and filters need justification without excluding contrary results?', 'Search run; amendment; source/publication')
add('S07','S','Items12–13: Updates and Dates of searches',
'Report update methods and dates; preserve changed strategy details.','reporting recommendation',
'Baseline, pilot revisions and future search refresh.',
'Store each run’s actual date and linked predecessor; retain old/new strategies and reasons. Distinguish publication cut-off, search date and access date. The current baseline remains 2026-10-04 pending a reasoned amendment.',
'How will coverage be backfilled after a concept-driven query change?', 'Search run; amendment')
add('S08','S','Item14: Peer review, requirement and explanation',
'Describe actual search-specific peer review.','reporting recommendation',
'Future search acceptance, not substitute for scholarly or independent human review.',
'Record reviewer role, independence, scope, feedback and action only if they exist. Keep PRESS as a deferred lead. A second model pass can be disclosed as another tool check, not a fictional librarian review.',
'Is genuine search-expert review available, and what limits apply without it?', 'Assistance/review; human gate')
add('S09','S','Items15–16; Figure1 caption, PDF p15',
'Report per-source totals and deduplication procedures.','reporting recommendation',
'Empirical evidence flow and raw discovery provenance.',
'Preserve each duplicate hit’s provenance while counting unique reports and studies correctly. Use PRISMA2020 flow semantics, not the PRISMA2009 example reproduced in this PRISMA-S paper.',
'How will false duplicate merges and publication families be audited?', 'Search run/hit; source/publication; study identity')
add('S10','S','Part5, paragraph beginning “Currently, PRISMA-S does not address…”',
'Every search-term rationale is not required by PRISMA-S.','explicit limit',
'Clarifies the basis of this project’s stronger decision audit.',
'Continue project-required query/concept rationale and exposure logging, but label it a project safeguard. Do not attribute a complete AI search-development or rationale-recording standard to this source.',
'What minimum decision trail makes interpretation inspectable without fictitious completeness?', 'Amendment; assistance/review; search run')
add('C01','C','Background; Methods: Formulating the review question',
'Interpretive questions can evolve rather than remain fixed hypotheses.','authors’ methodological argument',
'RQ1/RQ2 and later conceptual integration, not all empirical eligibility.',
'Use provisional sensitizing concepts and versioned problem definitions. Preserve rival meanings instead of enforcing the project’s preferred meaning taxonomy before reading primary arguments.',
'Which concepts are initial retrieval aids rather than inclusion rules?', 'Theoretical extraction; amendment')
add('C02','C','Methods: Searching the literature; Sampling; Table2, PDF p10',
'Purposive then theoretical sampling supported concept development.','reported practice and rationale',
'Conceptual corpus selection with a bounded scope statement.',
'Log why a text or edition was added, what argument/negative case it tests and residual gaps. Do not call this an exhaustive systematic census or copy the original project’s sample sizes as a quota.',
'What operational stopping and negative-case checks are appropriate here?', 'Source/publication; search run; theoretical extraction; amendment')
add('C03','C','Methods: Determination of quality; Table1, PDF p4',
'Conceptual relevance and methodological quality informed different judgments.','reported practice and rationale',
'Theoretical appraisal only after explicit adaptation; empirical appraisal remains distinct.',
'Do not install the original five prompts as a universal quality score for books, arguments and experiments. A weak study’s conceptual interest cannot promote its effect estimate to credible performance evidence.',
'Which theory-fidelity and empirical bias criteria are fit for each source type?', 'Appraisal; theoretical/empirical extraction; claim')
add('C04','C','Methods: Data extraction, both paragraphs; PDF p4',
'Formal extraction was incomplete; its value remained unsettled.','reported limitation',
'Important difference from this repository’s provenance expectations.',
'Retain exact locators and separate assertion/interpretation for all load-bearing claims as a stricter project choice. Permit bounded reading notes, but never label unread ranges fully extracted.',
'What minimal extraction record is sufficient for theory without implying whole-book coverage?', 'Theoretical extraction; source/publication; assistance/review')
add('C05','C','Methods: Conducting an interpretive synthesis; Discussion: CIS',
'CIS concerns the review process, not synthesis alone.','authors’ methodological argument',
'Repository work packages organize labour but cannot erase conceptual iteration.',
'Allow controlled conceptual feedback to search/selection work after earlier stages; proposals affecting empirical rules need impact assessment and any required reopening/rework. Do not silently bypass the programme dependency gates.',
'Who can authorize a cross-stage methodological amendment and its rework?', 'Amendment; assistance/review; protocol')
add('C06','C','Methods: Lines of argument synthesis; Refutational syntheses',
'Synthesising arguments connect constructs; critique includes contradictions.','authors’ methodological argument',
'Future interpretation and synthesis, not outcomes produced in 1B.',
'Separate primary author premises, our reconstruction, cross-source inference and design hypotheses. Record counterarguments and alternatives; do not relabel an engineering preference as a discovered construct or new contribution.',
'What would genuinely challenge the eventual argument rather than merely decorate it?', 'Theoretical extraction; appraisal; claim')
add('C07','C','Discussion: Reflections on the method, paragraphs1–3 and7–8',
'Interpretive products are not inherently reproducible.','authors’ reflexive limit',
'Bounds any reproducibility claim for the theoretical track.',
'Target inspectable provenance, reasons, preserved alternatives and reproducible calculations—not guaranteed identical theory. Describe the limit of an audit trail for intuitive sampling rather than claiming that logging eliminates it.',
'How will alternative interpretations and sensitivity to source selection be examined?', 'Assistance/review; theoretical extraction; claim')
add('C08','C','Methods: Formulating the review question, final paragraph; Analysis; Discussion: Reflections',
'Multidisciplinary deliberation shaped the reported interpretation.','reported practice',
'Transfer limitation for the present single-assistant preparatory work.',
'Disclose lack of equivalent disciplinary deliberation and independent human checking. Defer actual expert critique to authorized human gates; model self-checking does not reproduce the original team process.',
'Which expertise is necessary later for primary-source fidelity and empirical methods?', 'Assistance/review; human gate')
csvwrite('matrices/SOURCE_TO_DECISION.csv',rows)
intro='''# Source-to-decision matrix

[Packet index](../README.md) · [Adaptation memo](../findings/TWO_TRACK_ADAPTATION.md)

**Provisional applicability analysis, not a compliance checklist, accepted protocol, implemented schema or completed study.** The source-claim column is a short paraphrase. The action and open-question columns are this assistant's project-specific interpretation; no action below was implemented in repository records. All checks are agent-only. P = PRISMA 2020, S = PRISMA-S, C = original CIS. Exact source URLs, record-family routing and verification status are in the companion CSV. Packet IDs are local cross-references, not live research IDs.

Coverage is intentionally bounded to the requested topics. Reading all checklist items does not make this a full item-by-item compliance assessment. PDF pages are 1-based file pages; screenshot indices are documented separately.
'''
for a,name in [('P','PRISMA 2020'),('S','PRISMA-S'),('C','Critical interpretive synthesis')]:
    subset=[r for r in rows if r['anchor']==a]
    view=[{'ID':r['id'],'Exact locator':r['exact_locator'],'Source claim':r['source_claim'],'Applicability':r['applicability'],'Proposed repository action':r['proposed_repository_action'],'Unresolved question':r['unresolved_question'],'Verification': 'Agent passage/image check; provisional action; no independent human check'} for r in subset]
    intro+='\n## '+name+'\n\n'+table(view,list(view[0]))+'\n'
put('matrices/SOURCE_TO_DECISION.md',intro)
put('readings/PRISMA_2020.md',f'''# Reading record — PRISMA 2020 anchor

[Matrix: P01–P10](../matrices/SOURCE_TO_DECISION.md) · [Coverage ledger](../provenance/READING_COVERAGE.csv)

## Identity and version

Page MJ, McKenzie JE, Bossuyt PM, et al. *The PRISMA 2020 statement: an updated guideline for reporting systematic reviews*. **Systematic Reviews 10:89, published 29 March 2021**, DOI `10.1186/s13643-021-01626-4`. This is the official co-publication actually read, not a claim to have read the BMJ PDF. The official PRISMA statement page lists the co-publications. The checklist cites the BMJ version, `10.1136/bmj.n71`; these are the same statement family, not independent methodological evidence.

Primary [statement]({P}) and [PDF](https://link.springer.com/content/pdf/10.1186/s13643-021-01626-4.pdf); official [statement route](https://www.prisma-statement.org/prisma-2020-statement); [two-page checklist]({PC}); [expanded checklist]({PE}). Accessed **2026-10-04** via web retrieval.

## Actual reading and image coverage

The statement's main narrative was read from Introduction through Conclusion, with attention to Scope and How to use; Box1 glossary was inspected as a page image. Figure1 was inspected as a page image. The bibliography was scanned only for identified deferred references, not read as a corpus. File length: **11 pages**. Visually inspected **p3 (index2), p8 (index7)**. Table1 was covered using the official checklist, not separately as an article screenshot. The article's abstract-reporting Table2 was not systematically inspected.

The official checklist's **two complete pages** were read visually, including all 27 items and subitems. The ten-page expanded checklist was selectively read: introductory framing and selected items3–13a, 13d and16, plus24–27; contiguous neighbouring content was sometimes exposed. Page images inspected: **pp2,3,4,5,7,10 (indices1,2,3,4,6,9)**. Do not infer that unlisted pages or the full Explanation and Elaboration paper were read.

Reading status: **selected_ranges_read for the anchor; complete two-page checklist read**. Source passages and the specified images were checked by the assistant; no independent human source-fidelity check occurred. Exact locators for each retained point are in P01–P10.

## Retained methodological points

P01–P10 distinguish reporting from conduct, protocol reporting from review reporting, and records/reports/studies. They route selection, outcome, synthesis, amendment and disclosure information into proposed future repository records. Those routes are **our adaptation**, not a source-endorsed database design. In particular, P02's Git/date/exposure and P06's outcome separation are not declared source compliance.

## Access and limits

The first official DOI click returned a tool Internal Error. An official co-publication was then accessible in full HTML/PDF; therefore no statement access gap remains. The separate full BMJ Explanation and Elaboration paper (`10.1136/bmj.n160`), PRISMA-P and other linked guidance were **not read**. The expanded checklist is abridged supporting material, not a substitute for claiming the full E&E was inspected.

No source PDF or HTML is redistributed in this packet. Version identity uses DOI, publisher and accessed URL. External raw-byte SHA-256 is **unavailable: the web tools did not supply a local original byte file**. No hash is invented. The screenshot locators are reproducible access leads, not byte-pinned archival copies. Article findings about reporting uptake were not independently evaluated and are not used as project efficacy evidence.
''')
put('readings/PRISMA_S.md',f'''# Reading record — PRISMA-S anchor

[Matrix: S01–S10](../matrices/SOURCE_TO_DECISION.md) · [Coverage ledger](../provenance/READING_COVERAGE.csv)

## Identity and version

Rethlefsen ML, Kirtley S, Waffenschmidt S, et al., with the PRISMA-S Group. *PRISMA-S: an extension to the PRISMA Statement for Reporting Literature Searches in Systematic Reviews*. **Systematic Reviews 10:39, published 26 January 2021**, DOI `10.1186/s13643-020-01542-z`. Primary [HTML]({S}) and [PDF](https://link.springer.com/content/pdf/10.1186/s13643-020-01542-z.pdf). Accessed **2026-10-04** via web retrieval. This is the published article and its incorporated Explanation and Elaboration, not an earlier draft.

## Actual reading and image coverage

Read the title/abstract and substantive main narrative, including Introduction/development, Part2 Checklist, **all sixteen item requirements and their explanations in Part3**, and Part5 Discussion and conclusions. Published exemplars were read as illustrations inside this guidance, not independently verified studies or MHAC search records. The linked development datasets, supplementary search files and cited articles were not opened. Table2's glossary was not separately visually audited.

File length: **19 pages**. Visually inspected **Table1, p4 (index3)**; **Table3, p11 (index10)**; and **Figure1, p15 (index14)**. Figure1 is explicitly a **PRISMA2009 example**, not the current PRISMA2020 flow specification. S09 therefore requires version reconciliation rather than copying that image unchanged.

Reading status: **selected_ranges_read** at whole-item level because supplementary/development material and the complete reference apparatus were not reviewed; all material search-reporting items were read. Verification was by the assistant only, with no independent human check. Detailed decision locators are S01–S10.

## Retained methodological points

The matrix separates required reporting of methods actually used from decisions about which methods are appropriate. It also identifies source-specific totals, deduplication and updates as future record needs. S10 deliberately marks an extra project requirement: detailed term/concept decision rationales are not all mandated by PRISMA-S.

## Access and limits

Full HTML and PDF were accessible; no source access blocker remains for this bounded reading. References to PRESS, ROSES, PRISMA-P and other guidance are **discovery/access leads only**. Their original contents were not read. Current AI-review standards and performance thresholds are not established by this 2021 document.

No external source text/PDF is packaged. Original byte hash: **unavailable through the web retrieval used**. The source's examples and reported development process are author-reported material, not this assistant's reproduced experiments. Recording zero contacts or no peer review is preferable to inventing these activities; the paper does not authorize outreach, purchase or recruitment.
''')
put('readings/CIS_2006.md',f'''# Reading record — original critical interpretive synthesis anchor

[Matrix: C01–C08](../matrices/SOURCE_TO_DECISION.md) · [Adaptation memo](../findings/TWO_TRACK_ADAPTATION.md)

## Identity and version

Dixon-Woods M, Cavers D, Agarwal S, et al. *Conducting a critical interpretive synthesis of the literature on access to healthcare by vulnerable groups*. **BMC Medical Research Methodology 6:35, published 26 July 2006**, DOI `10.1186/1471-2288-6-35`. Primary [HTML]({C}) and [PDF](https://link.springer.com/content/pdf/10.1186/1471-2288-6-35.pdf). Accessed **2026-10-04** via web retrieval. This is the original methodological paper requested, not a later secondary summary.

## Actual reading and image coverage

Read the abstract for orientation, Background, and the complete Methods sequence: Formulating the review question; Searching the literature; Sampling; Determination of quality; Data extraction; Conducting an interpretive synthesis, including reciprocal translation, lines of argument, refutation and Analysis. Read the methodological Discussion, Reflections on the method and Conclusion. Healthcare-result illustrations were seen in adjacent passages but **the complete healthcare findings section and its underlying primary studies were not read or appraised**. References were not followed.

PDF length **13 pages**. Inspected **Table1, p4 (index3)** and **Table2, p10 (index9)** as screenshots, including table headings/footnotes and surrounding methodological qualifications. Table1's stated original use was empirical papers, not reviews; it is not a validated all-purpose score for philosophical books or HCI experiments.

Whole-item status: **selected_ranges_read**. Material methodological passages were read contiguously; no full-item or full-corpus reading is asserted. Verification was an assistant passage/image check, not independent human or disciplinary review. C01–C08 contain exact section locators.

## Source type and transfer limit

This is a **reflexive methodological account and argument grounded in a healthcare review**, not an empirical validation of MHAC's two-track protocol. The original team practice is not claimed to have been reproduced here. Healthcare constructs, examples and sample counts have no status as auditory-interface evidence, theory-sampling quotas or project findings.

The adaptation must preserve the difference between reconstruction and new interpretation. C04 and C07 are particularly important boundaries: our more explicit extraction audit is a project choice, while inspectable provenance does not promise a uniquely reproducible conceptual synthesis. The memo identifies which feedback loops are proposed and which empirical gates remain fixed pending a formal amendment.

## Access and limits

HTML and PDF were accessible; no anchor access gap remains. No linked qualitative-synthesis literature was searched or read. Later evaluations of CIS and alternative interpretive methods are unresolved, not silently assumed to endorse this adaptation.

No source PDF/full text is included. External byte hash is **unavailable through this web retrieval**, not a fabricated value. The present work used one assistant, no subagents and no independent human source verification. Any later human critique needs actual feedback and authorization under the project's human gates.
''')
# Build a machine-readable, bounded source coverage ledger (packet metadata only).
coverage=[
 dict(id='A-P2020',url=P,version='Systematic Reviews 10:89; 2021-03-29; DOI 10.1186/s13643-021-01626-4',extent='Main narrative; Scope/How to use; Box1 and Figure1; selected bibliography leads',not_read='Full E&E; abstract checklist Table2 systematic audit; cited studies',pdf_pages=11,screenshot_pages_1based='3;8',reading_status='selected_ranges_read'),
 dict(id='A-P2020-C',url=PC,version='Official PRISMA2020 two-page checklist, accessed 2026-10-04',extent='All 27 items and subitems across both pages, visually inspected',not_read='No unlisted source contents implied',pdf_pages=2,screenshot_pages_1based='1;2',reading_status='full_checklist_read'),
 dict(id='A-P2020-E',url=PE,version='Official PRISMA2020 expanded checklist, accessed 2026-10-04',extent='Intro and selected items3–13a,13d,16,24–27; specified page images',not_read='Whole ten-page item detail audit; full separate BMJ E&E',pdf_pages=10,screenshot_pages_1based='2;3;4;5;7;10',reading_status='selected_ranges_read'),
 dict(id='A-PRISMAS',url=S,version='Systematic Reviews 10:39; 2021-01-26; DOI 10.1186/s13643-020-01542-z',extent='Main narrative; Parts2/3 all16 item requirements and explanations; Part5; Tables1/3 and Figure1',not_read='Separate Table2 glossary visual audit; linked supplements/data and cited sources',pdf_pages=19,screenshot_pages_1based='4;11;15',reading_status='selected_ranges_read'),
 dict(id='A-CIS2006',url=C,version='BMC Medical Research Methodology 6:35; 2006-07-26; DOI 10.1186/1471-2288-6-35',extent='Background; complete methodological subsections; methodological Discussion/Reflections/Conclusion; Tables1/2',not_read='Complete healthcare findings; underlying studies; linked references',pdf_pages=13,screenshot_pages_1based='4;10',reading_status='selected_ranges_read')]
for r in coverage:r.update(access_date='2026-10-04',access_status='full_text_available via web',verification_actor='assistant_agent_only',independent_human_review='none',source_byte_hash='unavailable_no_local_original_bytes',source_text_in_packet='no')
csvwrite('provenance/READING_COVERAGE.csv',coverage)
put('provenance/SOURCE_IDENTITIES.json',json.dumps(coverage,ensure_ascii=False,indent=2))
put('provenance/READING_COVERAGE.md','''# Reading and access coverage

[Three records](../README.md) · [Machine-readable coverage](READING_COVERAGE.csv)

Five textual objects belong to three anchors, not five independent methodological studies. Fifteen distinct PDF pages were visually inspected across those five PDFs. All source-specific conclusions are limited to the ranges recorded below. Bibliographic references encountered in these sources are leads, not new readings.

'''+table([{k:r[k] for k in ['id','extent','not_read','screenshot_pages_1based','reading_status']} for r in coverage],['id','extent','not_read','screenshot_pages_1based','reading_status'])+'''

Full HTML availability is not whole-item reading. Web-rendered content and page images were used; no original external file bytes were acquired for hashing. There are no primary source PDFs or full-text copies in the delivery packet. These limitations do not prevent the bounded applicability analysis; they prevent claims of a byte-pinned source archive, complete supporting-literature reading or independent source-fidelity audit.
''')
print(json.dumps({'matrix_rows':len(rows),'by_anchor':{a:sum(r['anchor']==a for r in rows) for a in 'PSC'},'source_objects':len(coverage),'screenshot_pages':sum(len(r['screenshot_pages_1based'].split(';')) for r in coverage)},indent=2))
