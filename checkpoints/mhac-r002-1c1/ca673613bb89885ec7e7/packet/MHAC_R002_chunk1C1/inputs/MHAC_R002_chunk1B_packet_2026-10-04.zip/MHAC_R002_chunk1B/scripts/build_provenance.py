"""Build the portable audit metadata; never calls GitHub or changes research registers."""
from pathlib import Path
from datetime import datetime,timezone
import csv,json,hashlib
R=Path(__file__).resolve().parents[1]
M='796151a33ec7a1acc026b239fe5c883312ebf40b'
B='131996f6ff8ef9337873f673cb9e6fbf76488053'
base='https://github.com/techrote/MachineHumanAudioCybersemiotics'
now=datetime.now(timezone.utc).isoformat()
def put(p,s):
 f=R/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s.strip()+'\n',encoding='utf-8')
def js(p,d):put(p,json.dumps(d,ensure_ascii=False,indent=2))
def cs(p,rows):
 with (R/p).open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
js('provenance/FINAL_DRIFT_CHECK.json',dict(recorded_utc=now,main_sha=M,historical_bootstrap_sha=B,branches=['bootstrap/research-programme','main'],open_prs=[],resources=['/response/turn46','/response/turn47'],checks='One final branch/open-PR read, not CI polling; same pins/collection as entry',snapshot_is_atomic=False,unpublished_work='unknown',raw_payload_preserved=False,representation='selected fields transcribed from actual connector output'))
js('provenance/ASSISTANCE_AND_LIMITS.json',dict(actor='ChatGPT assistant',deployment_build_identifier='not exposed',date='2026-10-04',work='Packet restoration, bounded remote reconciliation, three-anchor source reading and provisional applicability analysis',subagents=0,independent_human_reviewers=0,participant_data=0,tools_used=['GitHub connector GET reads','web primary HTML/PDF retrieval and page screenshots','container stdlib Python and shell in isolated workspace'],methodological_compliance='not assessed or claimed',protocol_freeze='not performed',research_registry_validation='not performed; R001 acceptance unavailable at inherited pin',source_rights='No external full source text or PDFs included; references and original notes only',source_byte_hashes='Unavailable for web-rendered sources; local packet files are hashed',private_reasoning='not included; only observable work and concise decision rationales',source_exposure='1A checkpoint/scope/RQ/queue and requested methodological anchors; project constraint and prior seeds known from supplied context; no new comparator or production corpus reading'))
# Stable source locations plus provenance-only tool IDs for this chat. No source text is reproduced.
web=[
 dict(id='W01',kind='official routing',url='https://www.prisma-statement.org/prisma-2020',result='Accessible official route; followed only statement/checklist support',refs=['turn905635view0','turn500249view0','turn736845view3','turn796602view0']),
 dict(id='W02',kind='access failure',url='https://www.prisma-statement.org/prisma-2020-statement',result='Initial click on first statement DOI link returned Internal Error. No inference of source absence. Official Systematic Reviews co-publication used successfully.',refs=[]),
 dict(id='W03',kind='anchor HTML',url='https://link.springer.com/article/10.1186/s13643-021-01626-4',result='Material main narrative and selected bibliography leads read; exact coverage in reading record',refs=['turn132236view0','turn178268view0','turn172114view0','turn866870view1','turn273721view0','turn131249view0','turn131249view1','turn131249view2']),
 dict(id='W04',kind='anchor PDF',url='https://link.springer.com/content/pdf/10.1186/s13643-021-01626-4.pdf',result='11 pages available; Box1 and Figure1 visually inspected',refs=['turn178268view4']),
 dict(id='W05',kind='official checklist PDF',url='https://www.prisma-statement.org/s/PRISMA_2020_checklist-ab3g.pdf',result='2/2 pages completely read as images',refs=['turn485830view3']),
 dict(id='W06',kind='expanded checklist PDF',url='https://www.prisma-statement.org/s/PRISMA_2020_expanded_checklist-w7ra.pdf',result='Selected text and six page images inspected; not whole-item reading',refs=['turn485830view4','turn132236view1','turn178268view1','turn178268view2','turn178268view3','turn443896view2']),
 dict(id='W07',kind='anchor HTML',url='https://link.springer.com/article/10.1186/s13643-020-01542-z',result='All16 reporting items and explanations; Part2/Part5; bounded main narrative and reference leads',refs=['turn905635view1','turn736845view1','turn485830view0','turn796602view3','turn485830view1','turn866870view2','turn273721view1','turn443896view1','turn131249view3']),
 dict(id='W08',kind='anchor PDF',url='https://link.springer.com/content/pdf/10.1186/s13643-020-01542-z.pdf',result='19 pages available; Tables1/3 and Figure1 visually inspected',refs=['turn162038view4']),
 dict(id='W09',kind='anchor HTML',url='https://link.springer.com/article/10.1186/1471-2288-6-35',result='Background/Methods and methodological Discussion/Reflections/Conclusion; not complete healthcare findings',refs=['turn905635view2','turn162038view0','turn736845view2','turn273721view2','turn443896view0']),
 dict(id='W10',kind='anchor PDF',url='https://link.springer.com/content/pdf/10.1186/1471-2288-6-35.pdf',result='13 pages available; Tables1/2 visually inspected',refs=['turn736845view4','turn796602view4','turn796602view5'])]
shots=[
 ('A-P2020',3,2,'Box1 glossary/scope','turn936080view0'),('A-P2020',8,7,'Figure1 flow','turn936080view1'),
 ('A-P2020-C',1,0,'Checklist page1','turn132236view2'),('A-P2020-C',2,1,'Checklist page2','turn132236view3'),
 ('A-P2020-E',2,1,'Items5–7','turn936080view4'),('A-P2020-E',3,2,'Items8–10a','turn936080view5'),('A-P2020-E',4,3,'Items10a–13a','turn866870view4'),('A-P2020-E',5,4,'Items13b–13e start','turn866870view5'),('A-P2020-E',7,6,'Items16a/b and adjacent material','turn866870view6'),('A-P2020-E',10,9,'Items24–27','turn936080view6'),
 ('A-PRISMAS',4,3,'Table1','turn736845view5'),('A-PRISMAS',11,10,'Table3','turn936080view3'),('A-PRISMAS',15,14,'Figure1 PRISMA2009 example','turn936080view2'),
 ('A-CIS2006',4,3,'Table1/appraisal/extraction','turn485830view5'),('A-CIS2006',10,9,'Table2','turn485830view6')]
cs('provenance/SCREENSHOT_LEDGER.csv',[dict(source_id=a,pdf_page_1based=p,screenshot_index_0based=i,feature=f,tool_result=t,inspection='visually inspected by assistant',source_images_in_packet='no') for a,p,i,f,t in shots])
js('provenance/WEB_ACCESS_LEDGER.json',dict(date='2026-10-04',scope='Only the three named anchors and their official supporting material; reference entries are deferred leads, not citation searches.',ledger_type='Resource/batch summary, not a raw per-call transcript or source export',resources=web,tool_timeout_control='web service controlled; no explicit timeout argument offered',source_files_downloaded_to_workspace=0,novelty_or_pilot_queries=0))
manifest=[]
def add(id,kind,ref,version,role,coverage,local,status,limit):
 manifest.append(dict(id=id,kind=kind,reference=ref,version_or_pin=version,authority_role=role,reading_coverage=coverage,local_holding=local,verification_status=status,limits=limit))
add('AUTH-USER','execution authority','Current user chunk1B instructions','2026-10-04 task','Highest task-specific boundary: read-only, bounded reading and packet','Complete current task','findings/ENTRY_RECONCILIATION.md (normalized scope, not verbatim prompt)','provided by user','No extension to full R002 or publication')
add('INPUT-1A','prior actual packet','inputs/MHAC_R002_chunk1A_packet_2026-10-04.zip','SHA256 d515cbebf715bb3f4473663b10217ba61b7770f607f7849ec8f9fe667fac63da','Prior bounded scope/input audit','Restored; checkpoint, scope note, RQ map and reading queue examined','inputs/MHAC_R002_chunk1A_packet_2026-10-04.zip','All44 manifest hashes, 45 members, CRC and external receipt matched','Contains partial six-file export, not full Git tree; 1A test results are historical')
add('AUTH-AGENTS','repository instruction',base+'/blob/'+M+'/AGENTS.md','blob aadf65132f52b7792bedea5298bbaad4e687be12','Execution/integrity authority below explicit current task','Full file re-read via GitHub.fetch_file','No raw file export; connector metadata in provenance/REMOTE_RECONCILIATION.json','Pinned read; /response/turn44','Landing clause overridden for this read-only chunk')
add('AUTH-RUNBOOK','repository instruction',base+'/blob/'+M+'/docs/AGENT_RUNBOOK.md','blob 7f6895a93a83f6f291141051f70a997f084e5eac','Reconciliation, provenance, checkpoint and acceptance rules','Full file re-read via GitHub.fetch_file','No raw file export; connector metadata in provenance/REMOTE_RECONCILIATION.json','Pinned read; /response/turn45','No CI re-audit or remote publication performed')
add('AUTH-1A-SCOPE','inherited pinned authorities',base+'/blob/'+M+'/docs/RESEARCH_PROTOCOL.md',M,'Six RQs/two-track construction and prior data-model routing','Used completed1A actual checkpoint/scope/RQ/queue rather than repeating full inventory','Within restored1A archive: source_export and findings/matrices','Prior audit verified as packet; same main pin rechecked','Construction instructions, not frozen protocol; not a fresh full-scope audit')
add('STATE-REMOTE','current observed remote facts',base,M,'Delta reconciliation and visible candidate check','Branches/openPRs; recent issue updates; final branches/openPRs','provenance/REMOTE_RECONCILIATION.json; provenance/FINAL_DRIFT_CHECK.json','Connector GET observations transcribed','Not atomic; unpublished work unknown; no full Git tree export')
for row in json.loads((R/'provenance/SOURCE_IDENTITIES.json').read_text()):
 add(row['id'],'primary methodological source',row['url'],row['version'],'Source assertions/guidance only; adaptation remains provisional',row['extent'],'Original notes only: readings/ and matrices/; no full texts','Assistant passage/page-image check; '+row['reading_status'],'No independent human check; no local original-byte hash; '+row['not_read'])
add('DERIVED-1B','original provisional analysis','matrices/SOURCE_TO_DECISION.csv','Local28 decisions; not registered research IDs','Applicability recommendations and open questions','Produced and checked this turn','matrices/; readings/; findings/','Source-located assistant analysis; not scientifically accepted','No protocol freeze, novelty synthesis, pilot/search/screening or competing schema')
cs('SOURCE_AUTHORITY_MANIFEST.csv',manifest)
put('findings/ENTRY_RECONCILIATION.md',f'''# Entry and scope reconciliation — delta only

[Checkpoint](../CHECKPOINT.md) · [Restore receipt](../provenance/RESTORE_1A_RECEIPT.json) · [Remote observations](../provenance/REMOTE_RECONCILIATION.json)

## Entry decision

**Proceed with bounded 1B.** The actual 1A archive was present, restored in a new task directory and verified against its supplied archive receipt and internal SHA256SUMS. It has45 members and44 listed payload hashes; all matched. The separately supplied 1A checkpoint matched the restored file. This is verification of packet integrity, not a new audit of every earlier source claim.

1A marks its own bounded reconciliation complete and explicitly retains the three-anchor review as useful. No material unresolved conflict blocks preparatory reading. Its full R002 workflow and R001 expanded infrastructure acceptance remain incomplete at the assessed pin. Bootstrap acceptance must not be promoted to R001 acceptance.

## Relevant remote delta

Main remains `{M}`; historical bootstrap head remains `{B}`. Entry and final branch/open-PR observations agree: two branches and no open PRs. An all-state issue update query since2026-10-04T14:58:00Z returned no entries. No newer published candidate or pre-existing applicability review was visible through these observations. Unpublished/local workers remain unknown, and no ownership was claimed.

AGENTS and the runbook were re-read in full at the pinned main. No full inventory, CI polling or new issue-acceptance audit was repeated. Current GitHub reads are captured as selected-field observations, not as raw full API exports. A later worker must reconcile any newer state before integration.

## Authority reconciliation

The current instruction restricts work to source verification and local notes; it overrides generic landing requirements. Acceptance requirements are not waived: no accepted R002 freeze follows from this chunk. The packet's recommendations remain below the future accepted protocol and any actual R001 schema. The three papers supply methodological guidance/arguments, not permission to contact people, submit work, buy access or alter the repository.

The scope ends before novelty/pilot work and before1C. No production corpus, source findings about auditory effectiveness, human-review capability or schema validity was inferred. The source-to-decision matrix is an advisory table, not a replacement protocol or machine-validated research register.

## Isolation and portability

Only a fresh local task workspace and new deliverables were written. The original1A inputs, other worker folders and sibling repositories were not altered. No shared GPU, USB, native-test or CI resource was used. No Git checkout was attempted in1B; the inherited source export remains partial and is not a verified complete Git tree.

The complete original1A ZIP and its original receipt are included byte-for-byte. External source texts and PDFs are not included; source locators and our bounded notes are. No secrets, participant data, private correspondence or unrelated personal material are included. Human action required for this bounded reading: none.
''')
put('logs/COMMANDS_AND_RESULTS.md','''# Commands and results — chunk1B

## Local execution

All shell/container commands in this chunk used an explicit **10000ms timeout**. They ran only in the new task workspace or read specified inputs/skill instructions. No command was used to mutate GitHub, another repository or shared hardware. No shell download, package install, git clone, repository test suite or research validator was run.

| Batch | Command/operation actually performed | Result and coverage |
|---|---|---|
| Entry files/clock/skill | `date -u`, list supplied1A files; read `/home/oai/skills/pdfs/SKILL.md` | Actual inputs existed; source-reading/PDF instructions read. |
| Isolated restoration | Python `tempfile.mkdtemp`, `zipfile` safe-name/duplicate/CRC checks and extraction into new directory |45 members restored; no prior workspace assumed. |
| Input verification | Python `hashlib.sha256` against original archive receipt and all44 manifest entries; compare separately uploaded checkpoint bytes | All passed; receipt saved. |
| Prior scope reading | Read restored checkpoint, scope note, RQ map and finite reading queue | Entry permits1B; did not repeat full repo inventory. |
| Initial artifacts | Create initial checkpoint, restore receipt, remote observation summary, preliminary CIS notes; copy original1A ZIP/receipt | Durable material existed before final packaging. Preliminary notes were replaced by final bounded records. |
| Reading output | `python scripts/build_content.py` | Three reading records,28 decision rows, five source-object coverage entries and15 screenshot-page locators. |
| Adaptation output | `python scripts/build_adaptation.py` | Provisional adaptation memo, nine open decision questions and six deferred method packages. |
| Provenance output | `python scripts/build_provenance.py` | Source/authority manifest, source/access/screenshot logs, scope delta and assistance limits. |
| Packet-only QA | `python scripts/verify_packet.py <packet-root>` and `python scripts/package_packet.py` | Actual final outcomes recorded in the external archive-verification receipt. Checks cover local syntax, references, hash/inventory/readability and nested1A integrity only. |

The packet construction scripts are supplied for inspection. They are not R001 implementation, schema validators or scientific tests. Rebuilding authored files changes payload hashes and requires regeneration of SHA256SUMS.

## Remote and primary-source tool operations

GitHub connector operations were GET-only: entry branch collection, openPR collection, all-state recent issue updates, pinned AGENTS/runbook files, and one final branch/openPR check. Exact queries and selected observed fields are in the provenance JSON files. Entry and final pins agree; no separate published candidate was found. No CI checks were polled or workflow jobs triggered.

Web operations were direct primary HTML/PDF retrieval, official supporting links, bounded opens/finds within those anchors, and specified page screenshots. The resource-batch ledger and coverage records document what was read; they are not raw tool-output/source-text archives. An initial PRISMA statement DOI click failed with Internal Error; the official co-publication resolved access. No additional deferred guidance, review comparator or corpus source was opened. There were no novelty or pilot queries.

Web/connector tools do not expose a per-call timeout argument; their own service limits applied. No repeated asynchronous polling or background work occurred.

## Tests not performed

Repository/regulatory/scientific acceptance tests: **zero** in1B. The four bootstrap tests inside1A remain historical results, not rerun1B tests. No live records exist here to validate, and an empty register was not used as evidence of completion. Source reading was checked by the assistant only, not independent human review. No statistical estimates or participant outcomes were calculated.
''')
print('Wrote source/authority manifest, scope delta and provenance logs.')
