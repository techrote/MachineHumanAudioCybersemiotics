"""Create and verify this portable packet without network access or repository mutation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,runpy,zipfile
R=Path(__file__).resolve().parents[1]
OUT=R.parent
archive=OUT/'MHAC_R002_chunk1B_packet_2026-10-04.zip'
receipt=OUT/'MHAC_R002_chunk1B_archive_verification.json'
files=sorted(p for p in R.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(R/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files),encoding='utf-8')
verify=runpy.run_path(str(R/'scripts/verify_packet.py'))['verify']
result=verify(R)
prefix='MHAC_R002_chunk1B/'
all_files=sorted(p for p in R.rglob('*') if p.is_file())
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in all_files:z.write(p,prefix+p.relative_to(R).as_posix())
expected={prefix+p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in all_files}
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    if len(names)!=len(set(names)) or set(names)!=set(expected):raise ValueError('Archive inventory mismatch')
    if z.testzip() is not None:raise ValueError('Archive CRC failure')
    total=0
    for name,digest in expected.items():
        data=z.read(name);total+=len(data)
        if hashlib.sha256(data).hexdigest()!=digest:raise ValueError('Archive payload mismatch: '+name)
record={'status':'PASS','verified_utc':datetime.now(timezone.utc).isoformat(),'archive_filename':archive.name,
 'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,
 'archive_top_directory':prefix.rstrip('/'),'members':len(names),'member_inventory_exact':True,
 'zip_crc_all_pass':True,'all_members_read_and_equal_local_payload':True,'uncompressed_bytes_read':total,
 'manifest_sha256':hashlib.sha256((R/'SHA256SUMS').read_bytes()).hexdigest(),'packet_verifier':result,
 'limitations':'No external source byte pin, complete Git tree, methodology compliance or scientific acceptance is asserted.'}
receipt.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
