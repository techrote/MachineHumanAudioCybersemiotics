"""Offline packet transport/consistency checks only; NOT MHAC scientific/registry validation."""
from __future__ import annotations
import argparse, ast, csv, hashlib, io, json, re, sys, zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

def must(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def parse_sums(text: str) -> dict[str, str]:
    result = {}
    for line in text.splitlines():
        digest, name = line.split('  ', 1)
        must(bool(re.fullmatch('[0-9a-f]{64}', digest)), 'Malformed SHA-256')
        p = PurePosixPath(name)
        must(not p.is_absolute() and '..' not in p.parts, f'Unsafe manifest name: {name}')
        must(name not in result, f'Duplicate manifest name: {name}')
        result[name] = digest
    return result

def verify_nested(path: Path, receipt: Path) -> dict:
    expected = json.loads(receipt.read_text(encoding='utf-8'))
    must(hashlib.sha256(path.read_bytes()).hexdigest() == expected['archive_sha256'], '1A archive receipt mismatch')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        must(len(names) == len(set(names)), 'Duplicate 1A ZIP member')
        must(z.testzip() is None, '1A ZIP CRC failure')
        prefix = 'MHAC_R002_chunk1A/'
        must(all(n.startswith(prefix) and '..' not in PurePosixPath(n).parts for n in names), 'Unsafe 1A ZIP path')
        sums = parse_sums(z.read(prefix + 'SHA256SUMS').decode('utf-8'))
        must(set(names) == {prefix + n for n in sums} | {prefix + 'SHA256SUMS'}, '1A member inventory mismatch')
        for name, digest in sums.items():
            must(hashlib.sha256(z.read(prefix + name)).hexdigest() == digest, f'1A hash mismatch: {name}')
    return {'status': 'PASS', 'members': len(names), 'verified_hashes': len(sums), 'original_archive_sha256_matches': True}

def verify(root: Path) -> dict:
    root = root.resolve()
    all_files = sorted(p for p in root.rglob('*') if p.is_file())
    must(not any(p.is_symlink() for p in root.rglob('*')), 'Symlink in packet')
    must(not any(p.name == '__pycache__' for p in root.rglob('*')), 'Bytecode cache in packet')
    sums = parse_sums((root/'SHA256SUMS').read_text(encoding='utf-8'))
    names = {p.relative_to(root).as_posix() for p in all_files}
    must(names == set(sums) | {'SHA256SUMS'}, 'Payload inventory differs from manifest')
    for name, digest in sums.items():
        must(hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, f'Hash mismatch: {name}')
    counts = {'utf8_files': 0, 'json_files': 0, 'csv_files': 0, 'python_files_parsed': 0, 'local_markdown_links_checked': 0}
    for p in all_files:
        if p.suffix == '.zip':
            continue
        text = p.read_text(encoding='utf-8'); counts['utf8_files'] += 1
        if p.suffix == '.json':
            json.loads(text); counts['json_files'] += 1
        elif p.suffix == '.csv':
            records = list(csv.DictReader(io.StringIO(text)))
            must(bool(records), f'Empty packet table: {p.name}')
            must(all(None not in row for row in records), f'Malformed table columns: {p.name}')
            counts['csv_files'] += 1
        elif p.suffix == '.py':
            ast.parse(text, filename=str(p)); counts['python_files_parsed'] += 1
        elif p.suffix == '.md':
            fenced = False
            for line in text.splitlines():
                if line.lstrip().startswith(('```','~~~')):
                    fenced = not fenced; continue
                if fenced: continue
                for dest in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', line):
                    if urlsplit(dest).scheme or dest.startswith('#'): continue
                    name = unquote(dest.split('#',1)[0].split('?',1)[0])
                    target = (p.parent/name).resolve()
                    must(target.is_relative_to(root) and target.exists(), f'Broken/escaping link in {p.name}: {dest}')
                    counts['local_markdown_links_checked'] += 1
    matrix = list(csv.DictReader((root/'matrices/SOURCE_TO_DECISION.csv').open(encoding='utf-8')))
    must(len(matrix)==28 and len({r['id'] for r in matrix})==28, 'Decision ID/row count mismatch')
    must({a:sum(r['anchor']==a for r in matrix) for a in 'PSC'} == {'P':10,'S':10,'C':8}, 'Anchor row coverage mismatch')
    must(all(r['implementation_status']=='not_implemented' and r['exact_locator'] and r['unresolved_question'] for r in matrix), 'Incomplete/proclaimed implemented advisory row')
    queue = list(csv.DictReader((root/'matrices/DEFERRED_GUIDANCE.csv').open(encoding='utf-8')))
    must(len(queue)==6 and all(r['reading_status']=='not_read' and r['access_status']=='not_attempted_in_1B' for r in queue), 'Deferred queue status mismatch')
    sources = json.loads((root/'provenance/SOURCE_IDENTITIES.json').read_text(encoding='utf-8'))
    shots = list(csv.DictReader((root/'provenance/SCREENSHOT_LEDGER.csv').open(encoding='utf-8')))
    must(len(sources)==5 and len(shots)==15, 'Source or screenshot count mismatch')
    must(len({(s['source_id'],s['pdf_page_1based']) for s in shots})==15, 'Duplicate screenshot-page count')
    sourceids = {s['id']:s for s in sources}
    for shot in shots:
        must(shot['source_id'] in sourceids, 'Unknown screenshot source')
        page=int(shot['pdf_page_1based']); idx=int(shot['screenshot_index_0based'])
        must(idx==page-1 and 1<=page<=sourceids[shot['source_id']]['pdf_pages'], 'Screenshot index mismatch')
    checkpoint=(root/'CHECKPOINT.md').read_text(encoding='utf-8')
    must('**COMPLETE — bounded chunk 1B only.**' in checkpoint and 'IN_PROGRESS' not in checkpoint, 'Checkpoint not finalized')
    nested = verify_nested(root/'inputs/MHAC_R002_chunk1A_packet_2026-10-04.zip',root/'inputs/MHAC_R002_chunk1A_archive_verification.json')
    return {'status':'PASS','scope':'Packet transport/syntax/internal consistency only; NOT research, registry, source-fidelity or scientific acceptance',
        'packet_files':len(all_files),'hashed_payload_files':len(sums),'manifest_excludes_itself':True,**counts,
        'decision_rows':len(matrix),'deferred_packages':len(queue),'source_objects':len(sources),'distinct_screenshot_pages':len(shots),
        'original_1A_nested_archive':nested,'repository_tests_run':0,'external_source_byte_hashes_verified':0}

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',nargs='?',type=Path,default=Path(__file__).resolve().parents[1])
    args=parser.parse_args()
    try:
        result=verify(args.root)
    except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
        print(json.dumps({'status':'FAIL','error':str(exc)}),file=sys.stderr);return 1
    print(json.dumps(result,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':
    raise SystemExit(main())
