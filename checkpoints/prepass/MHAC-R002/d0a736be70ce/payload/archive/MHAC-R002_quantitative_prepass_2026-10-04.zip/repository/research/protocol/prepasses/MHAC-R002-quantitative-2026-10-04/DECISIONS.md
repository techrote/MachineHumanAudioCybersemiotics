# Quantitative decision table

Original proposed policy, not a frozen protocol. Source IDs resolve in SOURCES.md. `COMMON` refers to EXTRACTION_CONTRACT.md. JSON and CSV contain the same 14 decisions in machine-readable form.

## D01 — Recognition: correctly map the cue/message on the first attempt at a specified exposure level

**Effect measure:** Proposed default: marginal risk difference / difference in participant-average accuracy, percentage points; log RR or marginal log OR only in separate prespecified compatible cells.

**Required extraction:** Joint COMMON fields plus number/identity of alternatives, scoring, confusion matrix if available, first-attempt denominator, per-participant proportions or adjusted marginal contrast+SE.

**Design compatibility:** Parallel and paired designs only with equivalent exposure and estimand and design-correct variances; item-generalization scope must match.

**Missing variance or correlation:** Recover valid paired/model SE; one binary event per person needs joint table; repeated trials need participant-aware uncertainty, not binomial n=trials.

**Multiplicity:** Retain cue-specific outcomes; select a prespecified exemplar or average an explicitly defined interchangeable cue set using V.

**Do not pool when:** Different meanings, chance levels or task policies; incompatible first-attempt/any-attempt success; conditional versus marginal OR; missing valid SE cannot enter inverse-variance pool.

**Sources:** M01 M03 M07.

## D02 — Correct action by a task-relevant deadline

**Effect measure:** Marginal risk difference in correct action by deadline; error/omission categories separately; no automatic conversion to recognition.

**Required extraction:** Action definition, hazard/context, deadline origin/value, first/final action, corrections/replays, denominator, misses/technical loss and analysis contrast.

**Design compatibility:** Same action opportunity, deadline and permitted repair policy; bundled interfaces remain bundled effects.

**Missing variance or correlation:** Unknown failures are not silently successes or deleted trials; use outcome/missingness sensitivity separately.

**Multiplicity:** Primary candidate within each task cell; other action definitions retained as secondary.

**Do not pool when:** Recognition-only keypress used as a proxy for real action; different deadline/repair policies; unsafe transfer from lab to real deployment.

**Sources:** M08 M01.

## D03 — Detection/discrimination versus identifying a message

**Effect measure:** Keep hit/false-alarm rates or specified sensitivity measure distinct from n-way recognition accuracy.

**Required extraction:** Signal/noise opportunities, decision criterion, false alarms, response options, sensitivity formula and zero-cell handling.

**Design compatibility:** Same signal-detection task and measure; discrimination does not identify semantic action.

**Missing variance or correlation:** No d-prime reconstruction from percent correct alone without justified design mapping.

**Multiplicity:** Multiple sensitivity/criterion measures remain labelled; do not choose largest effect.

**Do not pool when:** Missing false-alarm opportunities; differing detection and message-selection questions.

**Sources:** M01 M03.

## D04 — Response time for a clearly defined response population

**Effect measure:** Raw arithmetic mean difference in ms; separate mean-log contrast (exp gives ratio of geometric means); retain medians/quantiles as different summaries.

**Required extraction:** Clock onset/offset, sound duration, response event, correct/error inclusion, deadline/censoring, trimming/winsorization, means/SD or valid model contrast.

**Design compatibility:** Same clock, event, transformations and inclusion policy; post-onset and post-offset times not interchangeable without a justified conversion.

**Missing variance or correlation:** Recover paired SE or SDdiff; sensitivity in within-person r; no universal median-to-mean conversion.

**Multiplicity:** One prespecified timing endpoint per cell or explicit joint model; accuracy remains visible.

**Do not pool when:** Correct-only versus all attempts; speed emphasis differs; unknown trimming; no failure outcome alongside selected successful RT.

**Sources:** M02 M07 M11 M08.

## D05 — Performance after fixed training dose

**Effect measure:** Accuracy/action or latency contrast at prespecified training dose, not a training-efficiency effect.

**Required extraction:** Training duration/trials, feedback, criterion, exposures, immediate assessment point, randomized training/interface factors.

**Design compatibility:** Equal-dose comparisons answer a different question from training to equal criterion.

**Missing variance or correlation:** Unknown prior exposure or dose prevents alignment; missing dispersion handled within the actual outcome family.

**Multiplicity:** Prespecified immediate post-dose window; all learning blocks retained but not independent.

**Do not pool when:** Different doses pooled as equivalent; within-group pre/post change mistaken for an interface contrast.

**Sources:** M03 M08.

## D06 — Training burden to reach a criterion

**Effect measure:** Time/trials-to-criterion; success probability within training budget; censored time-to-event only with appropriate model.

**Required extraction:** Criterion, ceiling, stopping rule, feedback, unsuccessful learners, censoring, practice schedule, metric.

**Design compatibility:** Common criterion and budget; distinguish total elapsed time from trial counts.

**Missing variance or correlation:** Do not omit non-learners or assign them mean successful time; no variance borrowing across unlike criteria.

**Multiplicity:** Learning curves/blocks need covariance or separate displays; do not pick steepest interval.

**Do not pool when:** Different mastery thresholds; training time only among successful learners; incompatible time-to-event/count measures.

**Sources:** M08 M03.

## D07 — Delayed retention level versus loss from immediate performance

**Effect measure:** Delayed outcome contrast OR between-interface difference in retention change; never merge these estimands.

**Required extraction:** Exact delay, interim exposures/retraining, immediate baseline, attrition, 4-condition/time covariance or reported change contrast+SE.

**Design compatibility:** Same delay regime, training and retest policy; randomized between-interface contrast distinct from single-arm forgetting.

**Missing variance or correlation:** For change contrast use c-Sigma-c transpose; two correlations alone generally insufficient for four measurements.

**Multiplicity:** Predeclare delay windows; separate windows are correlated results, not extra studies.

**Do not pool when:** 24-hour and multiweek retention treated identical; relearning counted as unaided retention; missing change covariance.

**Sources:** M01 M03.

## D08 — Workload or effort during/after the task

**Effect measure:** Raw scale mean difference for same instrument/version/scoring; carefully specified SMD only for same construct across defensible instruments.

**Required extraction:** Instrument/version, raw/weighted TLX, overall/subscale, range/direction, timing, task duration, participant SD/model contrast.

**Design compatibility:** Same workload construct and scoring; subjective performance subscale is not observed action accuracy.

**Missing variance or correlation:** Missing scale dispersion does not justify assigning an SD; sensitivity only with comparable instrument evidence.

**Multiplicity:** Overall and subscales not separate independent confirmations; secondary families retain full results.

**Do not pool when:** Preference/annoyance/human-likeness substituted for workload; raw/weighted TLX or subscales declared equivalent without rationale.

**Sources:** M10 M07.

## D09 — Repeated measures / crossover / repeated trial comparisons

**Effect measure:** Prefer design-adjusted marginal contrast with SE; raw MD when common units; outcome-standardized g only with explicit denominator.

**Required extraction:** Participant pairing, sequence allocation, period/order/carryover, SDdiff or r, model/covariates, units/trials/items, missing pairs.

**Design compatibility:** Combine with parallel estimates only after exposure/period compatibility; otherwise stratify.

**Missing variance or correlation:** SDdiff squared = SDa squared + SDc squared - 2r SDa SDc; justified grid, not default r=.5; model covariance preferred.

**Multiplicity:** Repeated blocks/items do not increase independent participant n; all-pairwise contrasts may be linearly dependent.

**Do not pool when:** Unmodelled carryover/learning; trial count used as participant count; paired d_z pooled with between-subject g.

**Sources:** M01 M02 M07.

## D10 — Shared controls and multiple cue contrasts

**Effect measure:** One prespecified pair; compatible arm/contrast aggregation with a declared target; or full sampling covariance multivariate model.

**Required extraction:** Arm IDs/counts/SDs and contrast coefficient vectors; participant overlap; outcomes/timepoints; covariance basis.

**Design compatibility:** Independent arms sharing C: cov(A-C,B-C)=var(C); same people in all arms requires full covariance algebra.

**Missing variance or correlation:** Unknown covariances: report feasible/judged sensitivity; simple control-splitting is an approximation, not paired-data repair.

**Multiplicity:** Use independent contrast basis if A-B=(A-C)-(B-C); no redundant 3-contrast precision gain.

**Do not pool when:** Combining genuinely different cue families merely to avoid dependence; missing identifiable independent units.

**Sources:** M02 M12.

## D11 — Multiple publications or partially overlapping samples

**Effect measure:** One canonical result per quantity; updated/corrected report may supersede, not average with, its predecessor.

**Required extraction:** Publication family, study/experiment/sample IDs, overlap fractions/status, result IDs, corrections, conflicting values and locators.

**Design compatibility:** Cluster independent overlap components, not publication titles; same experiment reported twice is no new sample.

**Missing variance or correlation:** Unresolved duplicate status: most credible prespecified canonical result plus alternate-report sensitivity; leave unresolved conflict explicit.

**Multiplicity:** Link complementary results but do not add N; do not use review and primary study as independent observations.

**Do not pool when:** Same sample masquerades as independent study; unknown material overlap prevents credible covariance/cluster definition.

**Sources:** M06 M12.

## D12 — Missing variance, sparse outcomes and incompatible effect scales

**Effect measure:** Recover exact design-correct SE from CI/test; else descriptive estimate; SMD, OR, RR, RD remain distinct unless justified conversion.

**Required extraction:** CI level, df, exact paired t or one-df contrast F, variance type, zeros, model link, adjustments, unit and derivation.

**Design compatibility:** A test for the actual contrast may inform SE; omnibus ANOVA p or significance threshold cannot recover it.

**Missing variance or correlation:** No zero SD/SE substitution, no universal continuity correction; zero events/no variance may require another valid likelihood or non-pool; imputation flagged and sensitivity/exclusion repeated.

**Multiplicity:** No result selection based on whether variance or significance is convenient.

**Do not pool when:** Only p<.05; unspecified SE type; no defensible reconstruction; OR versus RR conflated; SDdiff used as common-scale standardizer.

**Sources:** M01 M02 M07.

## D13 — Across-study synthesis or structured non-pooling

**Effect measure:** Pool only within synthesis cell and valid independence model; otherwise labelled per-sample effects and uncertainty, no summary diamond.

**Required extraction:** Synthesis key, included and omitted records, reason codes, bias/transfer appraisal, assumptions, confidence limits, number of independent components.

**Design compatibility:** Small corpus: prespecified single effect or justified within-sample aggregation; random-effects option not a compatibility repair.

**Missing variance or correlation:** Show estimates with missing CI labelled not estimable; covariance-sensitive conclusions remain conditional.

**Multiplicity:** No significance vote counting; subgroup/moderator and selective outcome analyses not driven by results.

**Do not pool when:** Construct/design incompatibility; unresolvable overlap; sparse independent samples for requested inference; serious bias; selected-outcome coverage.

**Sources:** M03 M04 M05 M09.

## D14 — Inferential multiplicity and dependence-aware models

**Effect measure:** Descriptive marginal intervals unless a confirmatory family and adjustment were prespecified; no universal omnibus audio score.

**Required extraction:** Primary endpoint/cue/time hierarchy, all attempted analyses, family definition, adjustment, independent cluster count, df/leverage for robust model.

**Design compatibility:** CR2/Satterthwaite with explicit overlap-component clusters is a conditional future option, not a substitute for compatible outcomes.

**Missing variance or correlation:** Unknown V still needs working assumptions and sensitivity; random intercept alone does not supply sampling covariance.

**Multiplicity:** Prefer limited preregistered contrasts; a multi-outcome estimate is not evidence all endpoints improve; no p-based prioritization.

**Do not pool when:** Too few independent clusters or unstable df/leverage; unidentified variance components; model changes chosen for a desired conclusion.

**Sources:** M03 M12 M13.

