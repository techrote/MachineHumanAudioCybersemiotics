# Proposed quantitative extraction extension

**Draft interface to #1, not replacement schemas.** Extend the existing empirical extraction and identity records specified in `docs/DATA_MODEL.md`. Local field names below are proposals; preserve that workstream's accepted IDs, common provenance and lifecycle. A structurally valid extraction does not establish source fidelity or causal identification.

## COMMON fields needed before numerical synthesis

| Field group | Required content and why |
|---|---|
| Identity | Publication ID/version; study, experiment, sample, arm, cue, outcome, timepoint and canonical-result IDs; publication family; overlap component and known/possible/absent overlap, with evidence. Distinguish observed, randomized and analysed participant counts. |
| Provenance | Source locator including table/row/column or model/contrast; input record/version; reported versus derived value; transformation/formula/version; extractor and verification scope; explicit synthetic flag; correction/supersession lineage. |
| Population | Language proficiency, hearing criteria, experience, age/context restrictions; exclusions and attrition. A student's learned lab mapping is not silently transported to expert safety action. |
| Intervention/comparator | Actual sound exemplars and family labels, semantics/action mapping, number of response alternatives, voice/lexical content, duration and level, training/feedback, environment and distractors; identify matched component comparison versus bundled interface comparison. |
| Design | Randomization unit, parallel/paired/crossover/factorial/observational, sequence/period/counterbalance, practice/order adjustment, participants per arm/pair, trials/items per person, repeated blocks and item reuse, missing pairs. |
| Estimand key | Population; task; treatment/comparator; outcome operationalization; training/exposure; delay/window; failure/repair/replay policy; analysis population; effect scale and standardizer; participant versus trial weighting; marginal versus conditional interpretation. |
| Estimate | Signed contrast orientation, units, mean/proportion/log quantity, dispersion type (SD, SE, CI), CI level and df, n associated with that variance, baseline/comparator risk for binary interpretation, model link and covariates. Retain original and transformed values. |
| Dependence | SDdiff or paired t/CI; within-person outcome correlation; covariance of estimated contrasts separately; arm mean covariance or joint binary table; repeated-time covariance; shared-control ID; whether adjusted SE already accounts for repetition; assumptions and source of each covariance. |
| Outcome events versus missing data | Wrong action, omission, timeout, repeated request, correction, training failure and technical logging loss separately. Record whether an event is scored failure, observed as its own outcome, censored or genuinely unobserved. |
| Selection/multiplicity | All eligible outcomes/contrasts/timepoints; prespecified synthesis membership; primary/secondary status; selection/aggregation rule and weights; reason for excluded contribution; whether interval is marginal or simultaneous. |
| Appraisal/transport | Randomization/measurement/selection issues, confounding, outcome reporting coverage, accessibility, material task differences, bias rationale and downstream claim boundary. Do not reduce all domains to one numeric score. |

## Minimal machine-readable boundary for a future extraction

```json
{
  "canonical_result_id": "assigned-by-R001",
  "sample_id": "assigned-by-R001",
  "overlap_component_id": "resolved-before-synthesis",
  "estimand_key": {
    "outcome_family": "correct_action",
    "summary": "marginal_risk_difference",
    "time_origin": "audio_onset",
    "deadline_ms": null,
    "deadline_status": "not_reported",
    "exposure_policy": "fixed_dose",
    "failure_policy": "wrong_or_late_is_failure",
    "repair_policy": "not_reported"
  },
  "estimate": {"value": null, "unit": "probability_difference", "status": "not_extracted"},
  "variance": {"value": null, "status": "not_reported", "basis_ids": []},
  "dependence": {"within_person_r": null, "contrast_covariance_ids": [], "status": "unresolved"},
  "synthesis_status": "not_ready",
  "synthetic": true
}
```

This is an illustrative field shape, **not a schema-valid live source record**. A missing deadline or repair policy would block the corresponding narrowly defined synthesis; null does not mean zero or no repair. Fixtures remain under tests, never a live evidence register.

## Validation split

Schema-level checks cover types, finite estimates, positive SD/SE where applicable, probability/count ranges, metric/units, mutually exclusive variance states, and explicit missing reasons. Cross-record checks cover valid IDs, duplicate/correction precedence, overlap components, result membership, compatible estimand keys, independent counts and covariance dimensions/positive semidefiniteness. Source review verifies that IDs actually refer to the same people, scales mean what they claim, and published model uncertainty handles the design. Scientific review judges exchangeability, causal interpretation, missingness assumptions and generalization. None of those last judgments follows from passing JSON tests.

## Specific mathematical safeguards

A success count cannot exceed its corresponding denominator. Repeated trials cannot be substituted for independent people. Variance and correlation fields must distinguish the correlation of person-level outcomes from the correlation of estimated contrasts. Before applying a covariance matrix, check orientation, labels, diagonal agreement with squared SEs, symmetry and positive semidefiniteness. A singular matrix can describe exact contrast redundancy and must not be made invertible by silently adding an arbitrary ridge. Aggregate with a stated contrast vector or use a nonredundant basis.

A correction replaces the eligible version of a result, preserves the old extraction as superseded, invalidates its derived covariance/aggregate and triggers regeneration. Conflicting reports are not averaged to manufacture agreement. The small rehearsal canonicalizer tests exact duplicate IDs only; it does not implement the complete #1 identity or correction graph.
