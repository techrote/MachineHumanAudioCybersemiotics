# Quantitative-methods prepass findings

**Issue:** MHAC-R002 / #2. **Assessed main:** `796151a33ec7a1acc026b239fe5c883312ebf40b`. **Status:** analytical contribution, not protocol freeze, empirical synthesis, superiority ranking or #1 infrastructure acceptance. The 14-row decision table, extraction contract and proposed clauses accompany this report. Sources and exact reading limits are in SOURCES.md.

## What remains to be decided, and what this prepass resolves

The current synthesis instructions already reject pooling incompatible constructs and double-counting samples. They do not yet identify a quantitative target, selection hierarchy, covariance procedure or operational non-pooling rule. This prepass proposes those rules without revisiting the access status of the existing auditory-alert review. Prior methodology packets were not available locally; retrieved summaries were used only to identify the deferred statistical scope. No empirical audio-effect estimates informed the fixtures or policy choices.

The main proposed decision is to organize synthesis around the **question actually estimated**, not the sound-family label or the availability of an effect size. A short sound can yield a quick recognition response, incorrect action, expensive training and poor retention simultaneously. Those are separate questions. A project-level preference or a broad term such as comprehension cannot make their standardized effects commensurable.

## Outcome questions that must remain distinct

| Family | Question to identify | Important non-equivalence |
|---|---|---|
| Recognition | Does the listener correctly map the message after the stated exposure? | Detection, first-attempt recognition, success after replay and action execution are not the same endpoint. |
| Action | Is the required response appropriate, within the relevant deadline and allowed repair policy? | A label-selection keypress does not by itself establish situated action; wrong, omitted and late actions matter. |
| Latency | How long until which event, from which clock origin, among which responses? | Correct-only RT, all-response RT and time to eventual correction select different outcomes/populations. |
| Training | What performance follows a fixed training budget, or what budget is needed for mastery? | Equal training dose versus equal final mastery answers different questions; unsuccessful learners cannot disappear. |
| Retention | What persists after a specified delay and intervening exposure? | Delayed level, decrement from immediate performance and relearning burden are distinct. |
| Workload | What subjectively rated demand/effort occurs under a specified task and instrument? | Preference, annoyance, perceived urgency and observed errors are not workload proxies; TLX overall/subscales/scoring differ. |

These are original operational proposals informed by the estimand framework [M08], synthesis grouping guidance [M03], speed–accuracy methods [M11], and the instrument owner's workload definition [M10]. No universal audio-family ordering follows from them.

A useful synthesis key is `(population, task/semantics, A:C interface, exposure/training, outcome/event, timing, failure/repair policy, summary/scale, analysis unit, design constraints)`. Whether mean latency includes the acoustic message itself is especially important for brief interfaces: subtracting sound duration changes the question from end-to-end response burden to post-stimulus processing, and cannot automatically be done for every observation. Likewise an A:C comparison with different wording and training is a package comparison, not an isolated acoustic-style effect.

## Two correlations with opposite roles

For n paired participants, let A and C be participant-level measurements. A raw mean difference has

`Var(mean(A-C)) = (sA² + sC² - 2 r_person sA sC) / n`.

By contrast, for estimated contrasts y and prespecified weights a,

`Var(a'y) = a' V a = sum(a_i² Var(y_i)) + 2 sum(i<j)(a_i a_j Cov(y_i,y_j))`.

Positive pairing may reduce a contrast SE, while positive correlation between contrasts increases an average's SE. Treating either correlation as the other is a substantive error. A pairing correlation cannot generally populate the contrast-covariance matrix. [M01, M02; algebraic application]

When A, B and C are independent arm means, `Cov(A-C, B-C)=Var(C)`. When the same participants receive all conditions, it becomes `Cov(A,B)-Cov(A,C)-Cov(C,B)+Var(C)`. More generally, with condition covariance Sigma and contrast matrix C, `V = C Sigma C'`. This linear formula applies to raw mean/linear contrasts; nonlinear effect measures such as log odds ratios or standardized mean differences need their own delta-method/model covariance, not this raw-MD formula copied unchanged. Contrast orientation changes covariance signs. A-B equals (A-C)-(B-C), so retaining all three does not create a third independent contrast. Exact redundancy may make V singular; use an identified contrast basis or aggregate, not an arbitrary numerical ridge.

## Worked synthetic example: precision lost to false independence

The fixture is authored summary data, **not real participants or a simulation calibrated from audio evidence**. It stipulates three disjoint sample IDs and three interchangeable cue exemplars within each. Each contrast is an A-minus-C first-attempt recognition difference in percentage points, with supplied SE=2. There is no claim that those SEs were estimated from the nominal participant counts.

| Synthetic sample | Cue 1 | Cue 2 | Cue 3 | Equal-cue sample mean |
|---|---:|---:|---:|---:|
| S1 | 4 | 5 | 6 | 5 |
| S2 | 1 | 2 | 3 | 2 |
| S3 | -2 | -1 | 0 | -1 |

The illustrative target is the equal-weight average of these **three specified sample-population effects**, each with an equal mixture of these three cues. It is a finite target, not the mean of a superpopulation of studies. Equal sample and cue counts keep the point estimate at 2, isolating the precision error. Different sample effects do not invalidate a fixed finite weighted target; they do invalidate unqualified generalization to a common universal effect.

The deliberately incorrect independence calculation uses nine independent observations:

`mean = 18/9 = 2; Var_naive = 9×4 / 9² = 4/9; SE_naive = 0.666667`.

Under a stipulated within-sample compound-symmetric *contrast* correlation rho, each 3×3 block has diagonal 4 and off-diagonal 4rho. For one sample:

`Var(sample mean) = (3×4 + 6×4rho)/9 = (4/3)(1+2rho)`.

For the average of three independent sample means:

`Var(target estimate) = (4/9)(1+2rho)`.

Thus rho=.6 gives `Var=44/45=0.977778`, `SE=0.988826`. False independence gives **2.2 times too much inverse-variance precision**, or an SE that must increase by **48.3%** to account for this stipulated covariance. The phrase “48.3%” compares corrected SE with naive SE; equivalently the naive SE is 32.6% smaller than the corrected SE.

| Assumed contrast rho | SE | Conditional normal 95% interval | Correct variance / naive variance |
|---:|---:|---:|---:|
| -0.25 | 0.4714 | 1.0761 to 2.9239 | 0.5 |
| 0 | 0.6667 | 0.6934 to 3.3066 | 1.0 |
| 0.25 | 0.8165 | 0.3997 to 3.6003 | 1.5 |
| 0.50 | 0.9428 | 0.1521 to 3.8479 | 2.0 |
| 0.60 | 0.9888 | 0.0619 to 3.9381 | 2.2 |
| 0.75 | 1.0541 | -0.0660 to 4.0660 | 2.5 |
| 0.90 | 1.1155 | -0.1864 to 4.1864 | 2.8 |
| 1.00 | 1.1547 | -0.2632 to 4.2632 | 3.0 |

All intervals here use the normal quantile and **condition on the supplied variances and the chosen rho**. They are not random-effects intervals, account for neither variance-estimation uncertainty nor study-population sampling, and cannot validate small-k HKSJ/RVE performance. Whether an illustrative interval crosses zero is not an empirical finding or a correlation-selection rule. No one rho is asserted to be the unknown true value.

For a three-contrast equicorrelation matrix, mathematical feasibility requires `-1/2 <= rho <= 1`. The negative scenario is a stress test, not a substantive assertion about expected audio data. Real designs require source-informed bounds and a valid covariance matrix; arbitrary pairwise correlations need not form one. The singular endpoints can still be aggregated because no matrix inverse is used.

## Non-pooled alternative and repeated reports

`synthetic-results/NONPOOLED.md` and `nonpooled.csv` display all nine contrasts with their marginal intervals, grouped by sample, with no overall diamond or vote count. Each row has SE=2 and interval estimate ±3.919928. This makes the S1/S2/S3 differences visible instead of allowing a headline mean to conceal them. Nominal sample sizes are repeated labels, not additive independent n within a sample.

The raw fixture also includes three identical results from a second report of S1. A deliberately incorrect 12-row analysis yields `mean=2.75`, `SE=sqrt(1/3)=0.577350`: a duplicated favourable sample changes both weighting and apparent precision. Canonicalization removes exactly those three repeated-result rows, restoring nine results and three sample identities. A conflicting repeated result is rejected, not averaged. This is a minimal test of result identity, not a replacement for source-grounded publication/sample reconciliation. [M06]

## Second synthetic design: shared independent-arm control

A, B and C have independent n=20 arms, SD=100 ms, and means 620, 640 and 650 ms. Each arm mean variance is 500. Contrasts A-C=-30 and B-C=-10 each have variance 1000, but their covariance is 500 because they reuse C.

The equally weighted contrast-mixture estimate is -20 ms. False independence gives variance `(1000+1000)/4=500`, SE=22.3607. The correct covariance-aware variance is `(1000+1000+2×500)/4=750`, SE=27.3861. This target is a deliberately defined 50:50 mixture of A:C and B:C effects; it is not legitimate merely because the two arms both happen to be called non-speech. Here rho=.5 is derived from the stipulated arm design, not guessed.

## Third synthetic design: missing pairing correlation

The separate paired-RT fixture has n=25, means 620 and 650 ms and SDs 100 and 110 ms. Its mean difference is -30 ms throughout. At within-person r=0, its variance is 884 and SE=29.7321; at r=.5, variance=444 and SE=21.0713; at r=.9, variance=92 and SE=9.5917. A negative stress scenario and additional positive values are in the CSV. These are different from the main contrast-rho grid. Recovering a reported paired contrast SE would eliminate this particular missing-correlation problem; there is no reason to impute r again once that SE is available. [M02]

## Fourth synthetic design: paired binary margins do not identify precision

For one binary result per paired participant, the 40-person joint table is: both correct a=24; A-only correct b=10; C-only correct c=2; neither correct d=4. Marginal success probabilities are .85 and .65, giving RD=.20. For D in {-1,0,1}, the unbiased sample-variance estimate of the mean difference is

`Var(RD) = [ (b+c)/n - RD² ] / (n-1) = (.30-.04)/39 = 1/150`.

SE=0.081650, or 8.165 percentage points. The script independently checks this formula by enumerating the 40 **synthetic** difference values; it is not trial-level evidence.

Keeping only the same margins, possible values of a run from 20 to 26. Enumerating all seven feasible joint tables leaves RD=.20 but changes variance from `.16/39` to `.46/39`, and SE from **0.064051 to 0.108604**. These are logical joint-table bounds, not a 95% interval or a probability distribution over correlations. The raw margins alone do not identify which SE is correct. The simple normal interval is an algebra demonstration; sparse real paired outcomes may require a different inferential procedure. Marginal and matched conditional odds ratios also target different summaries and should not be silently substituted.

## Retention/change covariance and unit-of-analysis risks

A difference in retention changes, `(A_delayed-A_immediate)-(C_delayed-C_immediate)`, has contrast vector `(1,-1,-1,1)` if the measurement order follows that expression. Its variance is c'Sigma c, involving all relevant repeated-measurement covariances. A single pre/post correlation cannot generally identify it. Reported design-valid contrast SEs are valuable; otherwise show dependence sensitivity or keep delayed levels and changes separated.

Trials, cues, blocks and reports can all multiply rows while leaving the number of independent participants unchanged. With unequal trial counts, participant-average accuracy differs from a trial-weighted mean. With a fixed small stimulus set, a participant-only SE does not establish generalization to a new population of sound exemplars. The extraction must retain item identity and generalization scope rather than pretending the nominal trial count addresses both sources of variation. [M01; application to audio tasks]

## What to pool, and what not to pool

Use the 14-row DECISIONS/JSON/CSV table for implementation. First establish a meaningful synthesis cell; next resolve duplicate and overlap identities; next identify the effect and design-valid uncertainty; then use a prespecified single result, a justified covariance-aware aggregate or an adequate multivariate model. Missing variance excludes a result from inverse-variance pooling, not from the review. Uncertain overlap cannot be repaired by relabelling publications as independent clusters.

A random intercept represents variation in true effects; it does not reconstruct omitted sampling covariance from shared participants or controls. A future working V plus `rma.mv` and CR2/Satterthwaite inference is a possible route, subject to enough independent overlap components and diagnostics. The official package guidance was inspected; **no R model or robust estimator was fitted here**. With three synthetic samples, a bespoke complex model would add a misleading appearance of sophistication. [M12, M13]

For the forthcoming protocol, PROPOSED_PROTOCOL.md offers a conservative primary non-pooling route below five independent components, REML plus explicitly specified conservative HKSJ for otherwise eligible cells, and a separate guarded robust-model option. These cut-offs and modifications are proposed operational safeguards, not established sufficiency guarantees. They need review before freezing; this packet's exact algebra remains useful without adopting them.

## Non-pooling is a deliverable, not a missing analysis

SWiM is a reporting checklist, not proof that a synthesis method is valid. The proposed implementation maps items1–2 to the synthesis key and metric; items3–4 to declared aggregation/selection or non-pooling; items5–6 to heterogeneity and appraisal/uncertainty reasoning; items7–8 to grouped estimates with identifiable contributing samples; item9 to explicit precision, design and transfer limits. We inspected the checklist's two pages, not the full explanation paper. [M09]

A non-pooled cell should show the eligible set, actual contributors, missing uncertainty and omitted-contribution reasons, not only favourable estimates. Magnitude, direction, uncertainty and conditions can be compared without counting significant studies. Absence of a precise pooled result is not proof of no effect. Where direction-only information is all that survives, its lost magnitude and precision must be acknowledged, and dependent rows cannot be treated as independent votes. [M05]

## Implementation sequence and remaining choices

| Order | Intended paths / action | Acceptance connection |
|---|---|---|
| 1 | Preserve this additive prepass and fixture under the named research/protocol and tests/fixtures paths. | Actual methods basis and reproducible calculations available without a freeze. |
| 2 | Reconcile EXTRACTION_CONTRACT with #1 empirical/identity schemas and correction graph; add relevant cross-record tests there. | Independent units, missingness and source identity become representable. |
| 3 | Pilot the synthesis-key and 14 decisions on heterogeneous, actually read sources; include negative/incompatible cases. | Establish operational effect/eligibility rules without favourable-outcome selection. |
| 4 | Resolve concrete windows, training/exposure, action deadlines, standardizer and meaningful-effect criteria; review proposed k/df/inference safeguards. | Quantitative estimands and pooling/non-pooling rules ready for freeze. |
| 5 | Add the accepted clauses to the executable protocol through its owner; log exposure/amendments. Leave original draft labelled. | No silent freeze or overwriting theoretical-method rules. |
| 6 | Later #9/#10 implement extraction, analysis and verified library-based inference; retain source-fidelity review separately. | Empirical calculations and conclusions trace actual evidence, not this synthetic fixture. |

No existing schema, validator, workflow, RAG authority, programme status or protocol-freeze flag is replaced by this patch. The proposed extra tools/tests are disjoint filenames within #1's broader owned directories and require integrator coordination before publication. The task used one assistant with local self-checks; it is not independent human statistical review. All source and software reading scopes are explicit; no inaccessible text was inferred.
