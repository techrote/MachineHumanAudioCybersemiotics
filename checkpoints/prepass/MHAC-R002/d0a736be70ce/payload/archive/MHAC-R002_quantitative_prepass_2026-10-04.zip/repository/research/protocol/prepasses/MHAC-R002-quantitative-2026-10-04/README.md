# MHAC-R002 quantitative-methods prepass

**Draft analytical contribution — not protocol freeze or empirical findings.** Assessed repository commit: `796151a33ec7a1acc026b239fe5c883312ebf40b`. Date: 2026-10-04. Refs #2; this does not close it.

## Read the work

[Findings and worked calculations](FINDINGS.md) explain the estimands, dependence and sensitivity results. [Proposed protocol wording](PROPOSED_PROTOCOL.md) supplies concrete clauses and remaining pilot decisions. [Decision table](DECISIONS.md) gives 14 operational decisions, also as [JSON](decision_table.json) and [CSV](decision_table.csv). [Extraction contract](EXTRACTION_CONTRACT.md) defines the interface to #1 without replacing its schemas. [Sources](SOURCES.md) and [source ledger](sources.json) give exact locators, access and actual reading extent.

## Inspect the actual results

[Results JSON](synthetic-results/results.json), [correlation sensitivity](synthetic-results/contrast_sensitivity.csv), [paired RT sensitivity](synthetic-results/paired_rt_sensitivity.csv), and [non-pooled display](synthetic-results/NONPOOLED.md) are generated from the explicitly synthetic fixture under `tests/fixtures/mhac_r002_quant/`. No source papers or restricted participant data are bundled.

## Reproduce from repository root

```sh
python tools/mhac_r002_quant_prepass.py
python -m unittest discover -s tests -p 'test_mhac_r002_quant_prepass.py' -v
```

Python 3.11+; standard library only. The actual tested runtime is recorded in the packet verification metadata. No network, R, GPU, paid service or participants are required. The prototype guards synthetic input and tests a limited family of covariance calculations; it is not a general empirical meta-analysis library or #1 validator. The full bootstrap suite was not run locally because no complete repository checkout was available.
