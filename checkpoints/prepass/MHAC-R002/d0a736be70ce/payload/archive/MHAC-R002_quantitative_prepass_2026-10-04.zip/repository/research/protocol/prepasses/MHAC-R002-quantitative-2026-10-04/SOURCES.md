# Primary methods sources and reading limits

Targeted methods consultation, not an exhaustive methodology review. Source identifiers are local to this prepass, not replacements for #1 registry IDs. All accesses were on 2026-10-04. Source text/figures are not redistributed. Web-hosted software documentation is unpinned; production analysis must pin package versions and archive the chosen method specification.

## M01 — Cochrane Handbook v6.5 (2024), Chapter 6: Choosing effect measures and computing estimates of effect

Source: https://training.cochrane.org/handbook/current/chapter-06

Locator: 6.1.2.2; 6.2.1–6.2.9; 6.3; 6.4.1. Reading: `selected_ranges_read`; access: `full_text_available`.

Effect of interest versus scale; participant/trial units; paired/clustered data; extraction of suitable contrast uncertainty.

## M02 — Cochrane Handbook v6.5 (2024), Chapter 23: Including variants on randomized trials

Source: https://training.cochrane.org/handbook/current/chapter-23

Locator: 23.2.3–23.2.4; 23.2.7–23.2.7.4; 23.3.4–23.3.5. Reading: `selected_ranges_read`; access: `full_text_available`.

Paired effects and correlation sensitivity; carryover/period issues; shared-control options.

## M03 — Cochrane Handbook v6.5 (2024), Chapter 9: Preparing for synthesis

Source: https://training.cochrane.org/handbook/current/chapter-09

Locator: 9.1; 9.3.2–9.3.4, especially 9.3.3 and Table 9.3.c. Reading: `selected_ranges_read`; access: `full_text_available`.

Synthesis-specific questions; prespecified selection or aggregation of interchangeable measurements; document grouping changes.

## M04 — Cochrane Handbook v6.5 (2024), Chapter 10: Analysing data and undertaking meta-analyses

Source: https://training.cochrane.org/handbook/current/chapter-10

Locator: 10.3; 10.10.3–10.10.4, particularly 10.10.4.3–10.10.4.5. Reading: `selected_ranges_read`; access: `full_text_available`.

Random effects does not cure incompatible questions; uncertainty and prediction limitations with few studies; REML/HKSJ considerations.

## M05 — Cochrane Handbook v6.5 (2024), Chapter 12: Other synthesis methods

Source: https://training.cochrane.org/handbook/current/chapter-12

Locator: 12.2.1–12.2.2.1; chapter key points. Reading: `selected_ranges_read`; access: `full_text_available`.

Structured non-pooled synthesis; summary distributions without falsely precise pooled means; reject significance vote counting.

## M06 — Cochrane Handbook v6.5 (2024), Chapter 5: Collecting data

Source: https://training.cochrane.org/handbook/current/chapter-05

Locator: 5.2.1: Studies (not reports) as the unit of interest. Reading: `selected_ranges_read`; access: `full_text_available`.

Link multiple reports; preserve secondary details without counting the same study twice.

## M07 — Lakens (2013), Calculating and reporting effect sizes to facilitate cumulative science

Source: https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2013.00863/full

Locator: Sections on standardized mean differences in within-subjects designs; Table 1; DOI 10.3389/fpsyg.2013.00863. Reading: `selected_ranges_read`; access: `full_text_available`.

Specify the denominator: d_z, d_av and between-groups d/g are not interchangeable. Small-sample correction does not erase that distinction.

## M08 — ICH E9(R1) addendum (2019), estimands and sensitivity analysis

Source: https://database.ich.org/sites/default/files/E9-R1_Step4_Guideline_2019_1203.pdf

Locator: A.3.2 principal-stratum paragraph; A.3.3–A.3.4; printed pp.9–10, zero-based PDF pages10–11. Reading: `selected_ranges_read`; access: `full_text_available`.

Treatment, population, variable, event strategy and population summary define the question. Adapting this clinical planning framework to HCI is our proposal, not an ICH compliance claim.

## M09 — Campbell et al. (2020), SWiM checklist accompanying Synthesis without meta-analysis in systematic reviews

Source: https://www.equator-network.org/wp-content/uploads/2020/01/Synthesis-without-Meta-analysis-SWiM-Checklist.pdf

Locator: Checklist pp.1–2, items1–9; both page images inspected; parent article DOI 10.1136/bmj.l6890. Reading: `full_item_read`; access: `full_text_available`.

The two-page checklist was read, not the complete BMJ explanation article. Map grouping, metric, method, prioritization, heterogeneity, certainty, presentation, results and limits.

## M10 — NASA, NASA Task Load Index (TLX), official instrument overview

Source: https://www.nasa.gov/human-systems-integration-division/nasa-task-load-index-tlx/

Locator: Heading NASA Task Load Index (TLX), first two paragraphs and six subscale list; page marked historical reference. Reading: `selected_ranges_read`; access: `full_text_available`.

Subjective multidimensional workload; weighted overall score and six subscales. This overview does not establish interchangeability of raw/weighted scores or other workload instruments.

## M11 — Heitz (2014), The speed-accuracy tradeoff: history, physiology, methodology, and behavior

Source: https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2014.00150/full

Locator: SAT methodology: experimental manipulations and analysis techniques, opening paragraph; SAT manipulations / Verbal instructions; DOI 10.3389/fnins.2014.00150. Reading: `selected_ranges_read`; access: `full_text_available`.

A single speed/accuracy operating point mixes task demands and decision strategy. Preserve both outcomes and task instructions.

## M12 — metafor, Some Recommended Practices, official package documentation

Source: https://wviechtb.github.io/metafor/reference/misc-recs.html

Locator: Dependent estimates workflow: construct V, rma.mv, robust with clubSandwich; footnote on low degrees of freedom. Reading: `selected_ranges_read`; access: `full_text_available`.

Sampling covariance and true-effect heterogeneity are separate modelling layers; robust inference follows a stated working model.

## M13 — clubSandwich, Meta-analysis with cluster-robust variance estimation, official author documentation

Source: https://jepusto.github.io/clubSandwich/articles/meta-analysis-with-CRVE.html

Locator: Multilevel meta-analysis example, coef_test with CR2; coefficient-specific Satterthwaite df and explicit cluster note. Reading: `selected_ranges_read`; access: `full_text_available`.

CR2 and coefficient-specific degrees of freedom; explicitly choose the independent cluster. This software was inspected, not installed or executed here.

## M14 — Pustejovsky and Tipton (2022), Meta-analysis with Robust Variance Estimation: Expanding the Range of Working Models

Source: https://link.springer.com/article/10.1007/s11121-021-01246-3

Locator: Publisher abstract only; Prevention Science 23,425–438; online 2021; DOI 10.1007/s11121-021-01246-3. Reading: `abstract_only_read`; access: `abstract_only`.

Background lead only. Full paper not read; detailed operational recommendations in this packet rely on M12/M13, not an inferred full-paper reading.

## Prior methodology findings

Retrieved prior-chat orientation describes 1A/1B/1C1 work on RQ-to-method mapping, record families, reporting-versus-conduct distinctions and CIS adaptation, while deferring statistical/non-pooling rules. Their original packets are not mounted in this task workspace and were not re-opened or hash-verified. These summaries therefore informed scope only, not source claims or numerical assumptions. Current assessed repository authorities independently require the unresolved quantitative decisions. The auditory-review access investigation was not repeated.

## M15 — Röver, Knapp and Friede (2015)

Source: https://link.springer.com/article/10.1186/s12874-015-0091-1

Locator: Methods / Parameter estimation and Confidence intervals and tests, equations(5)–(11); Conclusions paragraphs1–3. Full text available; selected ranges read. The inspected equations define inverse-total-variance weighting, q, and q*=max(1,q). The modification can be conservative with few studies; it is not a universal guarantee. The article, not its arXiv version, is the basis used here.
