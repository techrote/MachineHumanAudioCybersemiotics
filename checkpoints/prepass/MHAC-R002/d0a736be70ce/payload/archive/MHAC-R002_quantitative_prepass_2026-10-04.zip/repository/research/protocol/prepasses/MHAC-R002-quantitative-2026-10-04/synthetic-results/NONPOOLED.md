# Synthetic non-pooled display

No empirical participants or audio-style findings. Estimates are percentage-point recognition differences A minus C. Each sample reuses the same people for its three cues. Intervals are marginal, not simultaneous. No overall summary or significance votes.

| Sample | Cue | Participants (not additive within sample) | Estimate | Conditional 95% interval |
|---|---|---:|---:|---:|
| SYN-SAMPLE-1 | SYN-EXEMPLAR-1 | 40 | 4.00 | 0.08 to 7.92 |
| SYN-SAMPLE-1 | SYN-EXEMPLAR-2 | 40 | 5.00 | 1.08 to 8.92 |
| SYN-SAMPLE-1 | SYN-EXEMPLAR-3 | 40 | 6.00 | 2.08 to 9.92 |
| SYN-SAMPLE-2 | SYN-EXEMPLAR-1 | 40 | 1.00 | -2.92 to 4.92 |
| SYN-SAMPLE-2 | SYN-EXEMPLAR-2 | 40 | 2.00 | -1.92 to 5.92 |
| SYN-SAMPLE-2 | SYN-EXEMPLAR-3 | 40 | 3.00 | -0.92 to 6.92 |
| SYN-SAMPLE-3 | SYN-EXEMPLAR-1 | 40 | -2.00 | -5.92 to 1.92 |
| SYN-SAMPLE-3 | SYN-EXEMPLAR-2 | 40 | -1.00 | -4.92 to 2.92 |
| SYN-SAMPLE-3 | SYN-EXEMPLAR-3 | 40 | 0.00 | -3.92 to 3.92 |
