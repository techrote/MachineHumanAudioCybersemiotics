# Explicitly synthetic quantitative-methods fixture

No empirical observations. The JSON contains authored estimates and supplied standard errors, not generated or observed participant measurements. The nominal participant counts label independent-unit structure only; they do not estimate the supplied variances.

Three disjoint samples each provide three same-question cue contrasts. A fourth publication repeats S1 exactly. The canonicalizer drops only those three repeated-result rows. A separate paired-RT example varies within-person correlation; an independent-three-arm example derives the shared-control covariance; a binary paired example enumerates feasible joint tables at fixed margins. Their units and estimands are separate and they are not pooled together.

All correlation-grid values are scenario assumptions except the covariance derived from the independent-arm fixture. No draw seed is needed: all calculations are deterministic. Negative controls are constructed explicitly by the unit tests, including live-data contamination, conflicting duplicate results, invalid correlation matrices and false independence. Successful tests are numerical/structural checks, not evidence an audio interface works.
