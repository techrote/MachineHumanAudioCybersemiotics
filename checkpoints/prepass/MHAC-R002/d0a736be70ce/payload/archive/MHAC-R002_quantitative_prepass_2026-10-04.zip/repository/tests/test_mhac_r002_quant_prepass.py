"""Known-answer and deliberate-defect checks; not scientific validation."""
from __future__ import annotations
import copy
import importlib.util
import json
import math
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("quant", ROOT / "tools/mhac_r002_quant_prepass.py")
assert spec and spec.loader
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

class QuantitativePrepassTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / "tests/fixtures/mhac_r002_quant/fixture.json").read_text())
        self.rows, _ = q.canonicalize(self.data["contrasts"])

    def test_known_main_answer(self):
        got = q.fixed_target(self.rows, .6)
        self.assertAlmostEqual(got["estimate"], 2)
        self.assertAlmostEqual(got["variance"], 44/45)
        self.assertAlmostEqual(got["se"], math.sqrt(44/45))

    def test_independence_limit(self):
        got = q.build(self.data)
        zero = next(s for s in got["contrast_correlation_sensitivity"] if s["rho"] == 0)
        self.assertAlmostEqual(zero["variance"], 4/9)
        self.assertAlmostEqual(zero["se"], got["naive_independent_rows"]["se"])

    def test_false_independence_defect_is_detected(self):
        correct = q.fixed_target(self.rows, .6)["variance"]
        defective = 4/9
        self.assertNotAlmostEqual(correct, defective)
        self.assertAlmostEqual(correct / defective, 2.2)

    def test_duplicate_defect_detected_and_deduplicated(self):
        result = q.build(self.data)
        self.assertEqual(result["unique_contrasts"], 9)
        self.assertEqual(len(result["duplicate_reports_removed"]), 3)
        self.assertAlmostEqual(result["incorrect_duplicate_publication_analysis"]["estimate"], 2.75)
        self.assertAlmostEqual(result["naive_independent_rows"]["estimate"], 2)

    def test_conflicting_duplicate_rejected(self):
        self.data["contrasts"][-1]["estimate"] += 1
        with self.assertRaisesRegex(ValueError, "conflicting repeated report"):
            q.build(self.data)

    def test_live_data_rejected(self):
        self.data["contrasts"][0]["synthetic"] = False
        with self.assertRaisesRegex(ValueError, "synthetic"):
            q.build(self.data)

    def test_mixed_estimand_rejected(self):
        self.rows[0]["estimand_id"] = "workload_is_not_accuracy"
        with self.assertRaises(ValueError): q.fixed_target(self.rows, .5)

    def test_invalid_correlation_matrix_rejected(self):
        for r in (-.51, 1.01, float("nan")):
            with self.assertRaises(ValueError): q.covariance([2, 2, 2], r)

    def test_psd_endpoints_no_inverse_needed(self):
        self.assertAlmostEqual(q.linear_variance([1/3]*3, q.covariance([2]*3, 1)), 4)
        self.assertAlmostEqual(q.linear_variance([1/3]*3, q.covariance([2]*3, -.5)), 0)

    def test_asymmetric_or_negative_variance_rejected(self):
        with self.assertRaises(ValueError): q.linear_variance([.5,.5], [[1,2],[0,1]])
        with self.assertRaises(ValueError): q.interval(0,-1)

    def test_pairing_variance_and_direction(self):
        a = q.paired_md(620,650,100,110,25,.5)
        b = q.paired_md(620,650,100,110,25,0)
        self.assertAlmostEqual(a["estimate"],-30)
        self.assertAlmostEqual(a["variance"],444)
        self.assertLess(a["variance"],b["variance"])

    def test_shared_control_algebra(self):
        r = q.build(self.data)["shared_control"]
        self.assertEqual(r["covariance_matrix"], [[1000,500],[500,1000]])
        self.assertAlmostEqual(r["covariance_aware"]["variance"],750)
        self.assertAlmostEqual(r["false_independence"]["variance"],500)

    def test_paired_binary_from_individual_differences(self):
        differences = [0]*24 + [1]*10 + [-1]*2 + [0]*4
        mu = sum(differences)/40
        variance = sum((x-mu)**2 for x in differences)/(39*40)
        result = q.paired_binary(24,10,2,4)
        self.assertAlmostEqual(result["estimate"],.2)
        self.assertAlmostEqual(result["variance"],1/150)
        self.assertAlmostEqual(result["variance"],variance)

    def test_binary_frechet_bounds(self):
        result = q.build(self.data)["paired_binary"]["same_margins_feasible_joint_tables"]
        self.assertEqual(len(result),7)
        self.assertAlmostEqual(min(x["variance"] for x in result),.16/39)
        self.assertAlmostEqual(max(x["variance"] for x in result),.46/39)
        self.assertTrue(all(math.isclose(x["estimate"],.2) for x in result))

    def test_binary_bad_counts_rejected(self):
        with self.assertRaises(ValueError): q.paired_binary(24,-1,2,4)
        with self.assertRaises(ValueError): q.paired_binary(24,1.5,2,4)

    def test_nonpooled_not_missing_or_duplicated(self):
        result = q.build(self.data)
        self.assertEqual(len(result["nonpooled"]),9)
        self.assertEqual(len({r["sample_id"] for r in result["nonpooled"]}),3)

    def test_deterministic(self):
        self.assertEqual(q.build(self.data), q.build(copy.deepcopy(self.data)))

if __name__ == "__main__": unittest.main()
