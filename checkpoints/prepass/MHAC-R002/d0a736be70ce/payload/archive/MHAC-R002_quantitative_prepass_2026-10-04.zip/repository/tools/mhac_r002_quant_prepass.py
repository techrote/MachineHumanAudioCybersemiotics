"""MHAC-R002 synthetic quantitative-methods rehearsal, NOT empirical evidence.

Python 3.11+, standard library only. Deterministic algebra; no simulated people.
The main target is a fixed equal-weight average of specified sample/cue effects,
not a random-effects population mean. Sampling variances are supplied synthetic
constants; normal intervals are conditional illustrations, not small-k inference.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import NormalDist
from typing import Any

Z = NormalDist().inv_cdf(0.975)
ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "tests/fixtures/mhac_r002_quant/fixture.json"
OUT = ROOT / "research/protocol/prepasses/MHAC-R002-quantitative-2026-10-04/synthetic-results"


def number(x: Any, label: str) -> float:
    if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x):
        raise ValueError(f"{label}: finite number required")
    return float(x)


def interval(estimate: float, variance: float) -> dict[str, float]:
    estimate, variance = number(estimate, "estimate"), number(variance, "variance")
    if variance < 0:
        raise ValueError("negative variance")
    se = math.sqrt(variance)
    return {"estimate": estimate, "variance": variance, "se": se,
            "lower_95": estimate - Z * se, "upper_95": estimate + Z * se}


def covariance(ses: list[float], rho: float) -> list[list[float]]:
    """Compound-symmetry *contrast* correlation, not within-person pairing r.

    Supports singular positive-semidefinite endpoints because aggregation does
    not invert V. The lower bound is exact for this chosen working structure.
    """
    if not ses:
        raise ValueError("no standard errors")
    ses = [number(s, "se") for s in ses]
    if any(s <= 0 for s in ses):
        raise ValueError("standard errors must be positive")
    rho = number(rho, "rho")
    lower = -1 / (len(ses) - 1) if len(ses) > 1 else -1
    if not lower <= rho <= 1:
        raise ValueError("correlation matrix is not positive semidefinite")
    return [[a * b * (1 if i == j else rho)
             for j, b in enumerate(ses)] for i, a in enumerate(ses)]


def linear_variance(weights: list[float], v: list[list[float]]) -> float:
    n = len(weights)
    if n == 0 or len(v) != n or any(len(row) != n for row in v):
        raise ValueError("dimensions disagree")
    weights = [number(w, "weight") for w in weights]
    v = [[number(x, "covariance") for x in row] for row in v]
    if any(not math.isclose(v[i][j], v[j][i], abs_tol=1e-12)
           for i in range(n) for j in range(n)):
        raise ValueError("asymmetric covariance matrix")
    result = math.fsum(weights[i] * v[i][j] * weights[j]
                       for i in range(n) for j in range(n))
    if result < -1e-10:
        raise ValueError("negative variance of linear contrast")
    return max(0.0, result)


def aggregate(rows: list[dict[str, Any]], rho: float) -> dict[str, float]:
    if not rows:
        raise ValueError("empty aggregation")
    keys = {(r["sample_id"], r["estimand_id"]) for r in rows}
    if len(keys) != 1:
        raise ValueError("aggregation crosses sample or estimand")
    w = [1 / len(rows)] * len(rows)
    y = math.fsum(number(r["estimate"], "estimate") for r in rows) / len(rows)
    v = covariance([r["se"] for r in rows], rho)
    return interval(y, linear_variance(w, v))


def canonicalize(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[str]]:
    """Exact duplicate publication results add provenance, not observations.

    Not a general identity resolver: canonical result IDs must be established
    upstream. Conflicting values are rejected, never averaged or silently picked.
    """
    found: dict[str, dict[str, Any]] = {}
    duplicates: list[str] = []
    fields = ("sample_id", "estimand_id", "cue_id", "estimate", "se", "n_participants")
    for row in rows:
        if row.get("synthetic") is not True:
            raise ValueError("only explicitly synthetic rows permitted")
        if not isinstance(row.get("canonical_result_id"), str) or not row["canonical_result_id"]:
            raise ValueError("missing canonical result ID")
        number(row["estimate"], "estimate")
        if number(row["se"], "se") <= 0:
            raise ValueError("nonpositive standard error")
        if type(row["n_participants"]) is not int or row["n_participants"] <= 1:
            raise ValueError("invalid participant count")
        key = row["canonical_result_id"]
        if key in found:
            if any(found[key][f] != row[f] for f in fields):
                raise ValueError(f"conflicting repeated report: {key}")
            duplicates.append(row["report_id"] + ":" + key)
        else:
            found[key] = dict(row)
    return list(found.values()), duplicates


def fixed_target(rows: list[dict[str, Any]], rho: float) -> dict[str, Any]:
    """Equal weights within sample, then equal weights across independent samples."""
    if len({r["estimand_id"] for r in rows}) != 1:
        raise ValueError("incompatible estimands")
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(row["sample_id"], []).append(row)
    summaries = {s: aggregate(rs, rho) for s, rs in sorted(groups.items())}
    k = len(summaries)
    if not k:
        raise ValueError("no samples")
    result: dict[str, Any] = interval(
        math.fsum(s["estimate"] for s in summaries.values()) / k,
        math.fsum(s["variance"] for s in summaries.values()) / k**2)
    result.update({"rho": rho, "independent_samples": k, "sample_estimates": summaries})
    return result


def paired_md(mean_a: float, mean_c: float, sd_a: float, sd_c: float,
              n: int, r: float) -> dict[str, float]:
    if type(n) is not int or n < 2:
        raise ValueError("at least two paired participants required")
    r = number(r, "pairing r")
    if not -1 <= r <= 1:
        raise ValueError("invalid pairing correlation")
    sd_a, sd_c = number(sd_a, "sd_a"), number(sd_c, "sd_c")
    if sd_a < 0 or sd_c < 0:
        raise ValueError("negative standard deviation")
    v = (sd_a**2 + sd_c**2 - 2 * r * sd_a * sd_c) / n
    return interval(number(mean_a, "mean_a") - number(mean_c, "mean_c"), max(0.0, v))


def paired_binary(a: int, b: int, c: int, d: int) -> dict[str, float]:
    """One binary outcome per paired participant; b=A-only, c=C-only success.

    Uses unbiased sample variance of D in {-1,0,1}, divided by n. Normal intervals
    are illustrative; sparse real tables require suitable small-sample methods.
    """
    if any(type(x) is not int or x < 0 for x in (a, b, c, d)):
        raise ValueError("joint counts must be nonnegative integers")
    n = a + b + c + d
    if n < 2:
        raise ValueError("at least two participants required")
    rd = (b - c) / n
    return interval(rd, ((b + c) / n - rd**2) / (n - 1))


def build(fixture: dict[str, Any]) -> dict[str, Any]:
    if fixture.get("synthetic") is not True:
        raise ValueError("synthetic-only fixture required")
    rows, duplicates = canonicalize(fixture["contrasts"])
    if len({r["estimand_id"] for r in rows}) != 1:
        raise ValueError("mixed questions in main fixture")
    naive = interval(math.fsum(r["estimate"] for r in rows) / len(rows),
                     math.fsum(r["se"]**2 for r in rows) / len(rows)**2)
    # Equal m in this fixture makes naive row mean identical to the target mean.
    counts = [sum(r["sample_id"] == s for r in rows) for s in {r["sample_id"] for r in rows}]
    if len(set(counts)) != 1:
        raise ValueError("main precision-isolation demonstration requires balanced cue counts")
    sensitivities = []
    for rho in fixture["contrast_rho_grid"]:
        result = fixed_target(rows, rho)
        result["variance_ratio_to_false_independence"] = result["variance"] / naive["variance"]
        result["se_ratio_to_false_independence"] = result["se"] / naive["se"]
        sensitivities.append(result)
    nonpooled = [{**r, **interval(r["estimate"], r["se"]**2)} for r in rows]
    p = fixture["paired_rt"]
    paired = [{"r_within_person": r, **paired_md(p["mean_a_ms"], p["mean_c_ms"],
               p["sd_a_ms"], p["sd_c_ms"], p["n"], r)} for r in p["r_grid"]]
    sc = fixture["shared_control"]
    arm_variances = {arm: sc[arm]["sd"]**2 / sc[arm]["n"] for arm in ("a", "b", "c")}
    va, vb, vc = (arm_variances[s] for s in ("a", "b", "c"))
    y1, y2 = (sc[s]["mean"] - sc["c"]["mean"] for s in ("a", "b"))
    v = [[va + vc, vc], [vc, vb + vc]]
    shared = {"covariance_matrix": v, "mean_differences": [y1, y2],
              "false_independence": interval((y1 + y2) / 2, (v[0][0] + v[1][1]) / 4),
              "covariance_aware": interval((y1 + y2) / 2, linear_variance([.5, .5], v))}
    bi = fixture["paired_binary"]
    actual = paired_binary(**bi)
    n = sum(bi.values()); successes_a = bi["a"] + bi["b"]; successes_c = bi["a"] + bi["c"]
    feasible = []
    for a in range(max(0, successes_a + successes_c - n), min(successes_a, successes_c) + 1):
        table = {"a": a, "b": successes_a - a, "c": successes_c - a,
                 "d": n - successes_a - successes_c + a}
        feasible.append({"joint_table": table, **paired_binary(**table)})
    raw = fixture["contrasts"]
    bad_duplicate = interval(math.fsum(r["estimate"] for r in raw) / len(raw),
                             math.fsum(r["se"]**2 for r in raw) / len(raw)**2)
    return {"schema_version": 1, "synthetic": True, "empirical_claim": False,
            "target": fixture["target"], "interval_method": "normal conditional on supplied variances; not random-effects inference",
            "unique_contrasts": len(rows), "independent_samples": len(counts),
            "duplicate_reports_removed": duplicates, "naive_independent_rows": naive,
            "contrast_correlation_sensitivity": sensitivities, "nonpooled": nonpooled,
            "paired_rt_sensitivity": paired, "shared_control": shared,
            "paired_binary": {"observed_joint_table": bi, "actual": actual,
                              "same_margins_feasible_joint_tables": feasible},
            "incorrect_duplicate_publication_analysis": bad_duplicate}


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", type=Path, default=FIXTURE)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args(argv)
    try:
        data = json.loads(args.fixture.read_text(encoding="utf-8"))
        result = build(data)
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "results.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        write_csv(args.out / "contrast_sensitivity.csv", result["contrast_correlation_sensitivity"],
                  ["rho", "estimate", "variance", "se", "lower_95", "upper_95", "variance_ratio_to_false_independence", "se_ratio_to_false_independence"])
        write_csv(args.out / "nonpooled.csv", result["nonpooled"],
                  ["synthetic", "report_id", "sample_id", "canonical_result_id", "cue_id", "n_participants", "estimate", "se", "lower_95", "upper_95"])
        write_csv(args.out / "paired_rt_sensitivity.csv", result["paired_rt_sensitivity"],
                  ["r_within_person", "estimate", "variance", "se", "lower_95", "upper_95"])
        lines = ["# Synthetic non-pooled display", "", "No empirical participants or audio-style findings. Estimates are percentage-point recognition differences A minus C. Each sample reuses the same people for its three cues. Intervals are marginal, not simultaneous. No overall summary or significance votes.", "", "| Sample | Cue | Participants (not additive within sample) | Estimate | Conditional 95% interval |", "|---|---|---:|---:|---:|"]
        for r in result["nonpooled"]:
            lines.append(f'| {r["sample_id"]} | {r["cue_id"]} | {r["n_participants"]} | {r["estimate"]:.2f} | {r["lower_95"]:.2f} to {r["upper_95"]:.2f} |')
        (args.out / "NONPOOLED.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f'OK: {result["unique_contrasts"]} synthetic contrasts, {result["independent_samples"]} independent synthetic samples; {len(result["duplicate_reports_removed"])} repeated-report rows removed.')
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.exit(1, f"FAIL: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
