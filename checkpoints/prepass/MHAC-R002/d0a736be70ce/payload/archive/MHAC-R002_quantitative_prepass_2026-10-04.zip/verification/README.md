# Verification record

`environment.json` records the actual runtime; `repository_assessment.json` records the read-only assessed commit/tree and source scopes. `commands.json`, `tests.log` and `verification.json` record the exact bounded executions and results. Temporary paths in command records are historical locations, not prerequisites for replay.

The additive patch was generated from the exact payload, checked and applied in a new empty local Git worktree, and every restored payload file was compared byte-for-byte; all 17 tests passed there. The assessed remote tree contains none of the proposed paths. A complete clone failed DNS, so this is not a claim that the entire baseline suite ran against a checkout of the assessed commit. The remotely observed existing baseline CI is not CI for this new work.

Two invalid CLI fixtures (synthetic=false and an infeasible three-contrast correlation) returned the expected exit code1 without writing outputs. Five generated result files reproduced identically. A full 9x9 quadratic-form calculation using exact rational arithmetic matched 44/45. JSON/CSV decision values, source references and added Markdown file links were checked.

Re-run from an unpacked packet with `python verify_packet.py --run-tests`. This verifies membership and SHA-256, reruns the 17 tests and checks deterministic regeneration of all five result files. The external ZIP verification receipt records a second run after ZIP extraction, plus CRC and the final ZIP hash; it is outside the ZIP to avoid circular hashing. Hashes and tests establish preservation and numerical consistency, not source truth or empirical effectiveness.
