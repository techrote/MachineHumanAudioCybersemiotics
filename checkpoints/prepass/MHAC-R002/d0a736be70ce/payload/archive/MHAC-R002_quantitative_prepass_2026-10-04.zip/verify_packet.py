"""Verify an unpacked MHAC-R002 packet; optionally rerun offline tests/results.

Manifest deliberately excludes itself. Verify the ZIP's external SHA-256 before
trusting this local script; hashes establish file identity, not scientific truth.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run-tests',action='store_true')
    args=ap.parse_args()
    root=Path(__file__).resolve().parent
    manifest=root/'SHA256SUMS'
    entries={}
    for line in manifest.read_text().splitlines():
        digest,rel=line.split('  ',1)
        path=(root/rel).resolve()
        if not path.is_relative_to(root) or rel in entries:
            raise ValueError('unsafe or duplicate manifest path')
        entries[rel]=digest
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ValueError('hash mismatch: '+rel)
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p != manifest and '__pycache__' not in p.parts}
    if actual!=set(entries):
        raise ValueError('manifest membership mismatch')
    output={'manifest_records':len(entries),'sha256':'all_match','membership':'exact_except_manifest_and_runtime_pycache'}
    if args.run_tests:
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
        repo=root/'repository'
        command=[sys.executable,'-m','unittest','discover','-s','tests','-p','test_mhac_r002_quant_prepass.py','-v']
        t=subprocess.run(command,cwd=repo,env=env,text=True,capture_output=True,timeout=30)
        output['test_exit']=t.returncode
        output['test_output']=t.stdout+t.stderr
        if t.returncode: raise RuntimeError(output['test_output'])
        with tempfile.TemporaryDirectory() as td:
            command=[sys.executable,str(repo/'tools/mhac_r002_quant_prepass.py'),'--out',td]
            run=subprocess.run(command,env=env,text=True,capture_output=True,timeout=30)
            if run.returncode: raise RuntimeError(run.stderr)
            expected=repo/'research/protocol/prepasses/MHAC-R002-quantitative-2026-10-04/synthetic-results'
            for p in Path(td).iterdir():
                if p.read_bytes()!=(expected/p.name).read_bytes():
                    raise ValueError('generated drift: '+p.name)
            if {p.name for p in Path(td).iterdir()}!={p.name for p in expected.iterdir()}:
                raise ValueError('generated file set drift')
            output['regenerated_files_identical']=len(list(Path(td).iterdir()))
    print(json.dumps(output,indent=2))

if __name__=='__main__': main()
